"""Resume Gate 3 from the completed Q1/Q2 artifacts after an interrupted run."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import platform
import time

import joblib
import pandas as pd

from data_pipeline import SEED, load_raw, split_years
from q2_optimize import fit_bootstrap_models, run_q2
from q3_robust import run_q3
from q4_pareto import run_q4
from q5_adaptation import run_q5
from run_gate3 import package_versions, sha256, write_stage3_report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("project_root", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    started = time.time()
    results_dir = root / "results"
    model_dir = results_dir / "model_objects"
    figure_dir = root / "manuscript" / "figures"

    raw_hash_before = sha256(args.input_csv)
    df = load_raw(args.input_csv)
    splits = split_years(df)
    train = splits["train"]
    train_validation = pd.concat([splits["train"], splits["validation"]]).sort_index()
    model = joblib.load(model_dir / "selected_model_train_2018_2023.joblib")
    q1_summary = json.loads((results_dir / "q1" / "q1_summary.json").read_text(encoding="utf-8"))
    bootstrap_path = model_dir / "bootstrap_catboost_models_20.joblib"
    if bootstrap_path.exists():
        bootstrap_models = joblib.load(bootstrap_path)
    else:
        bootstrap_models = fit_bootstrap_models(train_validation, model.features, n_models=20)
        joblib.dump(bootstrap_models, bootstrap_path)

    q2 = run_q2(
        model,
        train,
        train_validation,
        results_dir / "q2",
        figure_dir,
        bootstrap_models=bootstrap_models,
    )

    q3 = run_q3(
        model,
        train,
        q2["representative"],
        q2["support"]["Water_Quantity_liters_per_acre"],
        float(q2["main_optimum"]["Fertilizer_Quantity"]),
        results_dir / "q3",
        figure_dir,
        bootstrap_models=bootstrap_models,
    )
    q4 = run_q4(
        model,
        q2["representative"],
        q2["support"]["Water_Quantity_liters_per_acre"],
        q2["support"]["Fertilizer_Quantity"],
        bootstrap_models,
        results_dir / "q4",
        figure_dir,
    )
    q5 = run_q5(
        df,
        model,
        bootstrap_models,
        q2["representative"],
        q3["scenarios"],
        float(q3["robust"]["Water_Quantity_liters_per_acre"]),
        float(q2["main_optimum"]["Fertilizer_Quantity"]),
        results_dir / "q5",
        figure_dir,
    )

    summaries = {
        "q1": {"summary": q1_summary},
        "q2": q2,
        "q3": q3,
        "q4": q4,
        "q5": q5,
    }
    write_stage3_report(root / "stage3_results_validation.md", summaries)

    q1_gate = q1_summary["decision_model_quality_gate_passed"]
    q2_direction = q2["summary"]["bootstrap_effect_direction"]
    q2_recommendation_stable = (
        max(q2_direction["water_positive_rate"], 1 - q2_direction["water_positive_rate"]) >= 0.80
        and max(q2_direction["fertilizer_positive_rate"], 1 - q2_direction["fertilizer_positive_rate"]) >= 0.80
    )
    q3_rates = q3["summary"].get("response_model_variety_selection_rates", {})
    q3_recommendation_stable = bool(q3_rates) and max(q3_rates.values()) >= 0.70
    claim_rows = [
        {
            "claim": "Decision-safe yield response generalizes to future years",
            "status": "verified" if q1_gate else "supported with limitations",
            "evidence": "q1/holdout_metrics.csv and q1/selected_model_metric_intervals.csv",
            "limitation": "observational data and synthetic-looking ranges",
        },
        {
            "claim": "Question 2 single-point agronomic recommendation is stable",
            "status": "supported with limitations" if q1_gate and q2_recommendation_stable else "provisional",
            "evidence": "q2/q2_summary.json and q2/q2_price_budget_sensitivity.csv",
            "limitation": "depends on confirmed unit and price assumptions",
        },
        {
            "claim": "Question 3 robust variety-water recommendation is stable across response models",
            "status": "supported with limitations" if q1_gate and q3_recommendation_stable else "provisional",
            "evidence": "q3/q3_decision_comparison.csv and q3/q3_scenario_bootstrap_stability.csv",
            "limitation": "zero robustness price is data/model specific; three scenarios summarize record-level rather than monthly-panel climate",
        },
        {
            "claim": "Question 4 balance lies on the approximate Pareto frontier",
            "status": "verified" if q4["summary"]["independent_recalculation"]["number_of_strict_grid_dominators"] == 0 else "rejected",
            "evidence": "q4/q4_pareto_frontier.csv and q4/q4_summary.json",
            "limitation": "environment metric is normalized pressure, not measured emissions",
        },
        {
            "claim": "Question 5 Top-3 ordering is stable",
            "status": "supported with limitations" if q5["summary"]["ranking_uncertain"] else "verified",
            "evidence": "q5/q5_final_ranking.csv and q5/q5_bootstrap_ranks.csv",
            "limitation": "associational covariate adjustment; ranking probability must be shown",
        },
    ]
    pd.DataFrame(claim_rows).to_csv(
        results_dir / "claim_validation_status.csv", index=False, encoding="utf-8-sig"
    )

    traceability = pd.DataFrame(
        [
            ["Q1 factors and model accuracy", "manuscript/figures/q1_*", "results/q1/*", "code/q1_models.py"],
            ["Q2 water/fertilizer recommendation", "manuscript/figures/q2_*", "results/q2/*", "code/q2_optimize.py"],
            ["Q3 robust variety/water decision", "manuscript/figures/q3_*", "results/q3/*", "code/q3_robust.py"],
            ["Q4 Pareto balance", "manuscript/figures/q4_*", "results/q4/*", "code/q4_pareto.py"],
            ["Q5 Top-3 adaptation ranking", "manuscript/figures/q5_*", "results/q5/*", "code/q5_adaptation.py"],
        ],
        columns=["claim", "figure", "result", "code_entry"],
    )
    traceability["derived_data"] = "data/derived/modeling_frame_unimputed.csv"
    traceability["raw_input_sha256"] = raw_hash_before
    traceability.to_csv(results_dir / "traceability_manifest.csv", index=False, encoding="utf-8-sig")

    raw_hash_after = sha256(args.input_csv)
    manifest = {
        "random_seed": SEED,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "package_versions": package_versions(),
        "raw_input": str(args.input_csv),
        "raw_sha256_before": raw_hash_before,
        "raw_sha256_after": raw_hash_after,
        "raw_immutable_check_passed": raw_hash_before == raw_hash_after,
        "resumed_after_completed_q1_q2": True,
        "runtime_seconds_resume": time.time() - started,
        "primary_year_split": {"train": "2018-2022", "validation": "2023", "locked_test": "2024"},
    }
    (results_dir / "run_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {
                "status": "Gate 3 complete",
                "q1": q1_summary,
                "q2": q2["summary"],
                "q3": q3["summary"],
                "q4": q4["summary"],
                "q5": q5["summary"],
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
