"""Regenerate only Q2/Q3 figures after visual-layout adjustments."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from data_pipeline import FERTILIZER, WATER
from q2_optimize import make_q2_figures
from q3_robust import make_q3_figures


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_root", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    results = root / "results"
    figures = root / "manuscript" / "figures"

    q2_summary = json.loads((results / "q2" / "q2_summary.json").read_text(encoding="utf-8"))
    q2_compare = pd.read_csv(results / "q2" / "q2_optimum_comparison.csv")
    baseline = q2_compare[q2_compare["method"].str.contains("101x101")].iloc[0]
    main = q2_compare[q2_compare["method"].str.contains("301x301")].iloc[0]
    robust_opt = q2_compare[q2_compare["method"].str.contains("bootstrap", case=False)].iloc[0]
    dense = pd.read_csv(results / "q2" / "q2_dense_response_grid.csv")
    robust = pd.read_csv(results / "q2" / "q2_bootstrap_robust_grid.csv")
    effect_stability = pd.read_csv(results / "q2" / "q2_decision_effect_stability.csv")
    support = {
        WATER: tuple(q2_summary["water_support_q05_q95"]),
        FERTILIZER: tuple(q2_summary["fertilizer_support_q05_q95"]),
    }
    make_q2_figures(figures, dense, baseline, main, robust, robust_opt, support, effect_stability)

    scenarios = pd.read_csv(results / "q3" / "q3_climate_scenarios.csv")
    evaluation = pd.read_csv(results / "q3" / "q3_variety_water_grid.csv")
    decisions = pd.read_csv(results / "q3" / "q3_decision_comparison.csv")
    robust_decision = decisions[decisions["decision_rule"] == "max-min robust"].iloc[0]
    expected_decision = decisions[
        decisions["decision_rule"] == "probability-weighted expected value"
    ].iloc[0]
    model_stability = pd.read_csv(results / "q3" / "q3_response_model_stability.csv")
    make_q3_figures(
        figures,
        scenarios,
        evaluation,
        robust_decision,
        expected_decision,
        model_stability,
    )


if __name__ == "__main__":
    main()
