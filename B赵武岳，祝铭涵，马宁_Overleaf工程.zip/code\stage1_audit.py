"""Stage 1 read-only audit for the 2026 sugarcane modeling problem.

The script never alters the source CSV. It writes only derived audit tables and
machine-readable summaries to the requested output directory.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


TARGET = "Yield_Quintal_per_Acre"

CLIMATE = [
    "Month", "Temp_Min_C", "Temp_Max_C", "Temp_Avg_C", "Rainfall_Total_mm",
    "Rainfall_Seasonal_mm", "Humidity_%", "Solar_Radiation_MJ_m2_day",
    "Sunshine_Hours_hh_mm", "Wind_Speed_kmph", "Evapotranspiration_mm_day",
    "Dew_Point_C", "Heat_Stress_Days", "Frost_Days",
]
SOIL = [
    "Soil_Type", "Soil_pH", "EC", "Organic_Carbon_%", "Soil_Moisture_%",
    "Sand_%", "Silt_%", "Clay_%", "Soil_Depth_cm", "Water_Holding_Capacity_%",
    "Nitrogen_kg_per_acre", "Phosphorus_kg_per_acre", "Potassium_kg_per_acre",
    "Zinc_mg_per_kg", "Iron_mg_per_kg", "Copper_mg_per_kg",
    "Manganese_mg_per_kg", "Sulfur_kg_per_acre",
]
IRRIGATION = [
    "Irrigation_Frequency_Level", "Water_Quantity_liters_per_acre",
    "Irrigation_Method_Type", "Groundwater_Level_meters", "Water_Quality_Category",
]
PLANTING = [
    "Planting_Date", "Harvesting_Date", "Crop_Duration_Days", "Seed_Rate",
    "Row_Spacing_cm", "Row_Gap_cm", "Plant_Density", "Intercropping",
    "Weed_Control", "Soil_Condition_At_Planting", "Planting_Method", "Mulching",
    "Fertilizer_Split", "Drainage_Condition",
]
GROWTH = [
    "Germination_%", "Tillering_Count", "Cane_Height_cm", "Cane_Diameter_cm",
    "Internode_Length_cm", "Brix_Value", "Disease_Type", "Disease_Severity",
    "Pest_Level", "Growth_Stage",
]
FERTILIZER = ["Fertilizer_Type", "Fertilizer_Quantity", "Application_Timing"]
OPERATIONS = ["Pesticide_Usage", "Machinery_Use", "Labor_Input"]
LOCATION = [
    "Latitude", "Longitude", "Altitude_m", "State", "District", "Tehsil",
    "Agro_Cluster", "Khasra_No", "Sugar_Mill", "Region", "Year", "Season",
]


def infer_unit(column: str) -> str:
    explicit = {
        "Month": "category (Jan-Dec)",
        "EC": "unspecified",
        "Planting_Date": "datetime",
        "Harvesting_Date": "datetime",
        "Seed_Rate": "unspecified",
        "Tillering_Count": "count",
        "Disease_Severity": "ordinal category",
        "Pest_Level": "ordinal category",
        "Fertilizer_Quantity": "unspecified",
        "Pesticide_Usage": "unspecified",
        "Labor_Input": "unspecified",
        "Year": "year",
        "Khasra_No": "identifier",
        TARGET: "quintal/acre",
    }
    if column in explicit:
        return explicit[column]
    suffixes = {
        "_C": "deg C", "_mm": "mm", "_%": "%", "_kmph": "km/h",
        "_cm": "cm", "_meters": "m", "_m": "m", "_kg_per_acre": "kg/acre",
        "_mg_per_kg": "mg/kg", "_liters_per_acre": "L/acre",
        "_MJ_m2_day": "MJ/(m^2 day)", "_Days": "days",
    }
    for suffix, unit in suffixes.items():
        if column.endswith(suffix):
            return unit
    return "category or unspecified"


def dictionary_role(column: str) -> tuple[str, str, str]:
    """Return group, temporal role, and default modeling policy."""
    if column in CLIMATE:
        return "climate", "realized growing-season condition", "use for explanation; scenario input for advance decisions"
    if column in SOIL:
        return "soil", "pre-season fixed condition", "use after consistency and missingness treatment"
    if column in IRRIGATION:
        if column in {"Groundwater_Level_meters", "Water_Quality_Category"}:
            return "water", "pre-season fixed condition", "use"
        return "water", "controllable management", "use; verify units and feasible support"
    if column in PLANTING:
        if column == "Harvesting_Date":
            return "planting/harvest", "post-season record", "exclude from advance model; current dates fail consistency"
        if column in {"Planting_Date", "Crop_Duration_Days"}:
            return "planting/harvest", "planned or recorded timing", "conditional; reconcile date semantics first"
        return "planting/harvest", "controllable or initial management", "use after missingness treatment"
    if column == "Variety":
        return "variety", "pre-season decision", "use; central to questions 3 and 5"
    if column in GROWTH:
        return "growth/stress", "intermediate or near-outcome measurement", "exclude from forward decision models; optional descriptive analysis only"
    if column in FERTILIZER:
        policy = "use; unit must be confirmed" if column == "Fertilizer_Quantity" else "use"
        return "fertilizer", "controllable management", policy
    if column in OPERATIONS:
        return "operations", "in-season management", "descriptive/conditional; availability at decision time must be stated"
    if column in LOCATION:
        if column in {"Khasra_No", "State", "District", "Sugar_Mill", "Region"}:
            return "location/context", "identifier or constant context", "exclude as direct predictor"
        return "location/context", "context or grouping variable", "use for grouping/validation; avoid memorization"
    if column == TARGET:
        return "outcome", "final outcome", "target only"
    return "unclassified", "unknown", "review manually"


def safe_rate(mask: pd.Series) -> float:
    valid = mask.dropna()
    return float(valid.mean()) if len(valid) else float("nan")


def add_check(rows: list[dict], name: str, evaluated: int, failed: int, note: str) -> None:
    rows.append(
        {
            "check": name,
            "evaluated_rows": int(evaluated),
            "failed_rows": int(failed),
            "failure_rate": float(failed / evaluated) if evaluated else np.nan,
            "note": note,
        }
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(args.input_csv, encoding="utf-8-sig")

    missing = pd.DataFrame(
        {
            "column": df.columns,
            "dtype": [str(df[c].dtype) for c in df.columns],
            "missing_n": [int(df[c].isna().sum()) for c in df.columns],
            "missing_rate": [float(df[c].isna().mean()) for c in df.columns],
            "unique_nonmissing": [int(df[c].nunique(dropna=True)) for c in df.columns],
        }
    ).sort_values(["missing_rate", "column"], ascending=[False, True])
    missing.to_csv(args.output_dir / "missingness_by_column.csv", index=False, encoding="utf-8-sig")

    # Restrained diagnostic chart; color distinguishes the exceptional disease field.
    top_missing = missing.head(15).sort_values("missing_rate")
    colors = ["#C44E52" if c == "Disease_Type" else "#4C78A8" for c in top_missing["column"]]
    fig, ax = plt.subplots(figsize=(8.2, 5.4), constrained_layout=True)
    ax.barh(top_missing["column"], top_missing["missing_rate"] * 100, color=colors)
    ax.set_xlabel("Missing records (%)")
    ax.set_title("Variables with the highest missingness")
    ax.grid(axis="x", color="#D9D9D9", linewidth=0.7)
    ax.set_axisbelow(True)
    for y_pos, value in enumerate(top_missing["missing_rate"] * 100):
        ax.text(value + 0.35, y_pos, f"{value:.1f}%", va="center", fontsize=8)
    for spine in ("top", "right", "left"):
        ax.spines[spine].set_visible(False)
    fig.savefig(args.output_dir / "fig_stage1_missingness.pdf")
    fig.savefig(args.output_dir / "fig_stage1_missingness.png", dpi=300)
    plt.close(fig)

    dictionary_rows = []
    for c in df.columns:
        group, time_role, policy = dictionary_role(c)
        dictionary_rows.append(
            {
                "column": c,
                "group": group,
                "dtype": str(df[c].dtype),
                "unit": infer_unit(c),
                "temporal_role": time_role,
                "default_policy": policy,
                "missing_n": int(df[c].isna().sum()),
                "missing_rate": float(df[c].isna().mean()),
                "unique_nonmissing": int(df[c].nunique(dropna=True)),
            }
        )
    pd.DataFrame(dictionary_rows).to_csv(
        args.output_dir / "data_dictionary_with_roles.csv", index=False, encoding="utf-8-sig"
    )

    row_missing = df.isna().sum(axis=1)
    row_missing.value_counts().sort_index().rename_axis("missing_fields").reset_index(
        name="row_count"
    ).to_csv(args.output_dir / "missingness_by_row.csv", index=False, encoding="utf-8-sig")

    numeric_rows = []
    for c in df.select_dtypes(include=np.number).columns:
        s = df[c]
        numeric_rows.append(
            {
                "column": c,
                "count": int(s.count()),
                "missing_rate": float(s.isna().mean()),
                "mean": float(s.mean()),
                "std": float(s.std()),
                "min": float(s.min()),
                "q01": float(s.quantile(0.01)),
                "q25": float(s.quantile(0.25)),
                "median": float(s.median()),
                "q75": float(s.quantile(0.75)),
                "q99": float(s.quantile(0.99)),
                "max": float(s.max()),
            }
        )
    pd.DataFrame(numeric_rows).to_csv(
        args.output_dir / "numeric_ranges.csv", index=False, encoding="utf-8-sig"
    )

    category_rows = []
    for c in df.select_dtypes(exclude=np.number).columns:
        counts = df[c].value_counts(dropna=False)
        for value, count in counts.items():
            category_rows.append(
                {
                    "column": c,
                    "value": "<MISSING>" if pd.isna(value) else str(value),
                    "count": int(count),
                    "rate": float(count / len(df)),
                }
            )
    pd.DataFrame(category_rows).to_csv(
        args.output_dir / "categorical_levels.csv", index=False, encoding="utf-8-sig"
    )

    checks: list[dict] = []

    # Temperature identities and ordering.
    temp = df[["Temp_Min_C", "Temp_Avg_C", "Temp_Max_C"]].dropna()
    fail = ~(
        (temp["Temp_Min_C"] <= temp["Temp_Avg_C"])
        & (temp["Temp_Avg_C"] <= temp["Temp_Max_C"])
    )
    add_check(
        checks,
        "temperature_order_min_le_avg_le_max",
        len(temp),
        int(fail.sum()),
        "Average temperature should normally lie between recorded minimum and maximum.",
    )
    midpoint_error = (temp["Temp_Avg_C"] - (temp["Temp_Min_C"] + temp["Temp_Max_C"]) / 2).abs()
    add_check(
        checks,
        "temperature_average_within_2C_of_midpoint",
        len(temp),
        int((midpoint_error > 2).sum()),
        "A diagnostic identity check only; daily/monthly averages need not equal the midpoint exactly.",
    )

    rain = df[["Rainfall_Seasonal_mm", "Rainfall_Total_mm"]].dropna()
    add_check(
        checks,
        "seasonal_rainfall_not_above_total",
        len(rain),
        int((rain["Rainfall_Seasonal_mm"] > rain["Rainfall_Total_mm"]).sum()),
        "Assumes total rainfall covers at least the season represented by seasonal rainfall.",
    )

    soil = df[["Sand_%", "Silt_%", "Clay_%"]].dropna()
    soil_sum = soil.sum(axis=1)
    add_check(
        checks,
        "soil_texture_sum_within_95_to_105_percent",
        len(soil),
        int(((soil_sum < 95) | (soil_sum > 105)).sum()),
        "Sand, silt, and clay fractions should approximately sum to 100% if they are exhaustive fractions.",
    )

    physical_ranges = {
        "humidity_0_100": ("Humidity_%", 0, 100),
        "soil_ph_0_14": ("Soil_pH", 0, 14),
        "soil_moisture_0_100": ("Soil_Moisture_%", 0, 100),
        "water_holding_0_100": ("Water_Holding_Capacity_%", 0, 100),
        "germination_0_100": ("Germination_%", 0, 100),
    }
    for name, (column, low, high) in physical_ranges.items():
        s = df[column].dropna()
        add_check(checks, name, len(s), int(((s < low) | (s > high)).sum()), f"Expected range [{low}, {high}].")

    # Date consistency.
    planting = pd.to_datetime(df["Planting_Date"], errors="coerce")
    harvesting = pd.to_datetime(df["Harvesting_Date"], errors="coerce")
    dates = pd.DataFrame(
        {"planting": planting, "harvesting": harvesting, "duration": df["Crop_Duration_Days"]}
    ).dropna()
    elapsed = (dates["harvesting"] - dates["planting"]).dt.total_seconds() / 86400
    add_check(
        checks,
        "harvest_not_before_planting",
        len(dates),
        int((elapsed < 0).sum()),
        "Harvesting must occur after planting for the same crop cycle.",
    )
    add_check(
        checks,
        "date_elapsed_matches_crop_duration_within_30_days",
        len(dates),
        int(((elapsed - dates["duration"]).abs() > 30).sum()),
        "Allows a 30-day tolerance because timestamps and duration definitions may differ.",
    )

    year = df["Year"]
    plant_year_valid = planting.notna() & year.notna()
    harvest_year_valid = harvesting.notna() & year.notna()
    add_check(
        checks,
        "planting_year_matches_year_field",
        int(plant_year_valid.sum()),
        int((planting[plant_year_valid].dt.year != year[plant_year_valid]).sum()),
        "Needs a data definition: Year may denote planting year, harvest year, or survey year.",
    )
    add_check(
        checks,
        "harvest_year_within_one_year_of_year_field",
        int(harvest_year_valid.sum()),
        int(((harvesting[harvest_year_valid].dt.year - year[harvest_year_valid]).abs() > 1).sum()),
        "Sugarcane cycles may cross a calendar year; differences above one year need explanation.",
    )

    # Disease semantics.
    disease_missing = df["Disease_Type"].isna()
    severity_present = df["Disease_Severity"].notna()
    add_check(
        checks,
        "disease_type_missing_but_severity_present",
        int(disease_missing.sum()),
        int((disease_missing & severity_present).sum()),
        "Missing disease type cannot automatically be interpreted as no disease when severity is recorded.",
    )

    checks_df = pd.DataFrame(checks)
    checks_df.to_csv(
        args.output_dir / "logical_consistency_checks.csv", index=False, encoding="utf-8-sig"
    )

    plot_checks = checks_df[checks_df["failure_rate"].notna()].copy()
    plot_checks["failure_pct"] = plot_checks["failure_rate"] * 100
    plot_checks = plot_checks.sort_values("failure_pct")
    fig, ax = plt.subplots(figsize=(9.0, 5.8), constrained_layout=True)
    bar_colors = ["#D55E00" if v >= 20 else "#E69F00" if v >= 5 else "#4C78A8" for v in plot_checks["failure_pct"]]
    ax.barh(plot_checks["check"], plot_checks["failure_pct"], color=bar_colors)
    ax.set_xlabel("Records failing the diagnostic check (%)")
    ax.set_title("Logical consistency diagnostics")
    ax.grid(axis="x", color="#D9D9D9", linewidth=0.7)
    ax.set_axisbelow(True)
    for y_pos, value in enumerate(plot_checks["failure_pct"]):
        ax.text(value + 0.7, y_pos, f"{value:.1f}%", va="center", fontsize=8)
    for spine in ("top", "right", "left"):
        ax.spines[spine].set_visible(False)
    fig.savefig(args.output_dir / "fig_stage1_consistency.pdf")
    fig.savefig(args.output_dir / "fig_stage1_consistency.png", dpi=300)
    plt.close(fig)

    # Association diagnostics, not a fitted model and not causal evidence.
    numeric = df.select_dtypes(include=np.number)
    pearson = numeric.corr(method="pearson")[TARGET].drop(TARGET).sort_values(key=np.abs, ascending=False)
    spearman = numeric.corr(method="spearman")[TARGET].drop(TARGET).sort_values(key=np.abs, ascending=False)
    corr = pd.DataFrame({"pearson": pearson, "spearman": spearman}).reset_index(names="column")
    corr["max_abs"] = corr[["pearson", "spearman"]].abs().max(axis=1)
    corr.sort_values("max_abs", ascending=False).to_csv(
        args.output_dir / "univariate_target_correlations.csv", index=False, encoding="utf-8-sig"
    )

    combos = (
        df.groupby(["Variety", "Season"], dropna=False)[TARGET]
        .agg(n="count", mean="mean", std="std", median="median")
        .reset_index()
    )
    combos["se"] = combos["std"] / np.sqrt(combos["n"])
    combos.to_csv(args.output_dir / "variety_season_counts.csv", index=False, encoding="utf-8-sig")

    monthly = (
        df.groupby("Month", dropna=False)
        .agg(
            n=(TARGET, "count"),
            temp_avg_c=("Temp_Avg_C", "mean"),
            rainfall_total_mm=("Rainfall_Total_mm", "mean"),
            rainfall_seasonal_mm=("Rainfall_Seasonal_mm", "mean"),
            humidity_pct=("Humidity_%", "mean"),
            solar_mj_m2_day=("Solar_Radiation_MJ_m2_day", "mean"),
            yield_mean=(TARGET, "mean"),
        )
        .reset_index()
    )
    monthly.to_csv(args.output_dir / "monthly_climate_summary.csv", index=False, encoding="utf-8-sig")

    year_counts = df["Year"].value_counts(dropna=False).sort_index().rename_axis("year").reset_index(name="rows")
    year_counts.to_csv(args.output_dir / "year_counts.csv", index=False, encoding="utf-8-sig")

    constant_columns = [c for c in df.columns if df[c].nunique(dropna=True) <= 1]
    near_unique_columns = [
        c for c in df.columns if df[c].nunique(dropna=True) / max(int(df[c].notna().sum()), 1) >= 0.90
    ]

    water = df["Water_Quantity_liters_per_acre"].dropna()
    water_mm_equivalent = water / 4046.8564224

    summary = {
        "source": str(args.input_csv),
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "target_missing": int(df[TARGET].isna().sum()),
        "exact_duplicate_rows": int(df.duplicated().sum()),
        "complete_rows": int((row_missing == 0).sum()),
        "rows_with_any_missing": int((row_missing > 0).sum()),
        "mean_missing_fields_per_row": float(row_missing.mean()),
        "median_missing_fields_per_row": float(row_missing.median()),
        "max_missing_fields_per_row": int(row_missing.max()),
        "constant_columns": constant_columns,
        "near_unique_columns": near_unique_columns,
        "khasra_nonmissing": int(df["Khasra_No"].notna().sum()),
        "khasra_unique_nonmissing": int(df["Khasra_No"].nunique(dropna=True)),
        "khasra_duplicated_nonmissing_rows": int(df["Khasra_No"].dropna().duplicated(keep=False).sum()),
        "water_quantity_l_per_acre_min": float(water.min()),
        "water_quantity_l_per_acre_max": float(water.max()),
        "water_equivalent_mm_min": float(water_mm_equivalent.min()),
        "water_equivalent_mm_max": float(water_mm_equivalent.max()),
        "target_mean": float(df[TARGET].mean()),
        "target_std": float(df[TARGET].std()),
        "target_min": float(df[TARGET].min()),
        "target_max": float(df[TARGET].max()),
        "target_skew": float(df[TARGET].skew()),
        "known_year_rows": int(df["Year"].notna().sum()),
        "unknown_year_rows": int(df["Year"].isna().sum()),
    }
    (args.output_dir / "audit_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print("\nLogical checks:")
    print(checks_df.to_string(index=False))
    print("\nTop target correlations (diagnostic only):")
    print(corr.sort_values("max_abs", ascending=False).head(15).to_string(index=False))
    print("\nVariety-season counts:")
    print(combos.to_string(index=False))


if __name__ == "__main__":
    main()
