"""Question 4: audited yield–environment Pareto optimization."""

from __future__ import annotations

from pathlib import Path
import json

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.core.problem import Problem
from pymoo.optimize import minimize

from data_pipeline import FERTILIZER, SEED, WATER, economic_cost_per_hectare
from q1_models import FittedRegressor
from q2_optimize import (
    BASE_BUDGET,
    BASE_FERTILIZER_PRICE,
    BASE_WATER_PRICE,
    candidate_frame,
    evaluate_grid,
)


def environmental_pressure(
    water: np.ndarray | float,
    fertilizer: np.ndarray | float,
    water_bounds: tuple[float, float],
    fertilizer_bounds: tuple[float, float],
    lambda_water: float = 0.5,
) -> np.ndarray:
    w = (np.asarray(water, dtype=float) - water_bounds[0]) / (water_bounds[1] - water_bounds[0])
    f = (np.asarray(fertilizer, dtype=float) - fertilizer_bounds[0]) / (
        fertilizer_bounds[1] - fertilizer_bounds[0]
    )
    w = np.clip(w, 0.0, 1.0)
    f = np.clip(f, 0.0, 1.0)
    return lambda_water * w**2 + (1.0 - lambda_water) * f**2


def nondominated_front(grid: pd.DataFrame) -> pd.DataFrame:
    ordered = grid.sort_values(["environmental_pressure", "predicted_yield"], ascending=[True, False])
    keep = []
    best_yield = -np.inf
    for idx, row in ordered.iterrows():
        value = float(row["predicted_yield"])
        if value > best_yield + 1e-10:
            keep.append(idx)
            best_yield = value
    return ordered.loc[keep].sort_values("environmental_pressure").reset_index(drop=True)


def select_ideal_distance(front: pd.DataFrame) -> tuple[pd.Series, pd.DataFrame]:
    work = front.copy()
    y_range = max(work["predicted_yield"].max() - work["predicted_yield"].min(), 1e-12)
    e_range = max(work["environmental_pressure"].max() - work["environmental_pressure"].min(), 1e-12)
    work["yield_loss_normalized"] = (
        work["predicted_yield"].max() - work["predicted_yield"]
    ) / y_range
    work["environment_normalized"] = (
        work["environmental_pressure"] - work["environmental_pressure"].min()
    ) / e_range
    work["distance_to_ideal"] = np.sqrt(
        work["yield_loss_normalized"] ** 2 + work["environment_normalized"] ** 2
    )
    return work.loc[work["distance_to_ideal"].idxmin()], work


def weighted_sum_baseline(grid: pd.DataFrame) -> pd.DataFrame:
    y = grid["predicted_yield"]
    e = grid["environmental_pressure"]
    y_norm = (y - y.min()) / max(y.max() - y.min(), 1e-12)
    e_norm = (e - e.min()) / max(e.max() - e.min(), 1e-12)
    rows = []
    for yield_weight in np.linspace(0, 1, 21):
        utility = yield_weight * y_norm - (1 - yield_weight) * e_norm
        idx = utility.idxmax()
        rows.append({"yield_weight": yield_weight, **grid.loc[idx].to_dict()})
    return pd.DataFrame(rows).drop_duplicates([WATER, FERTILIZER])


class YieldEnvironmentProblem(Problem):
    def __init__(
        self,
        model: FittedRegressor,
        representative: pd.Series,
        water_bounds: tuple[float, float],
        fertilizer_bounds: tuple[float, float],
        lambda_water: float,
    ) -> None:
        super().__init__(
            n_var=2,
            n_obj=2,
            n_ieq_constr=0,
            xl=np.array([water_bounds[0], fertilizer_bounds[0]]),
            xu=np.array([water_bounds[1], fertilizer_bounds[1]]),
        )
        self.response_model = model
        self.representative = representative
        self.water_bounds = water_bounds
        self.fertilizer_bounds = fertilizer_bounds
        self.lambda_water = lambda_water

    def _evaluate(self, x: np.ndarray, out: dict, *args, **kwargs) -> None:
        frame = candidate_frame(
            self.representative, self.response_model, x[:, 0], x[:, 1]
        )
        y = self.response_model.predict(frame)
        e = environmental_pressure(
            x[:, 0],
            x[:, 1],
            self.water_bounds,
            self.fertilizer_bounds,
            self.lambda_water,
        )
        out["F"] = np.column_stack([-y, e])


def nsga2_comparator(
    model: FittedRegressor,
    representative: pd.Series,
    water_bounds: tuple[float, float],
    fertilizer_bounds: tuple[float, float],
    lambda_water: float,
) -> pd.DataFrame:
    problem = YieldEnvironmentProblem(
        model, representative, water_bounds, fertilizer_bounds, lambda_water
    )
    result = minimize(
        problem,
        NSGA2(pop_size=120, eliminate_duplicates=True),
        termination=("n_gen", 140),
        seed=SEED,
        verbose=False,
        save_history=False,
    )
    x = np.asarray(result.X)
    frame = candidate_frame(representative, model, x[:, 0], x[:, 1])
    return pd.DataFrame(
        {
            WATER: x[:, 0],
            FERTILIZER: x[:, 1],
            "predicted_yield": model.predict(frame),
            "environmental_pressure": environmental_pressure(
                x[:, 0], x[:, 1], water_bounds, fertilizer_bounds, lambda_water
            ),
        }
    ).sort_values("environmental_pressure")


def frontier_distance(nsga: pd.DataFrame, grid_front: pd.DataFrame) -> dict[str, float]:
    y_min, y_max = grid_front["predicted_yield"].min(), grid_front["predicted_yield"].max()
    e_min, e_max = grid_front["environmental_pressure"].min(), grid_front["environmental_pressure"].max()
    scale_y, scale_e = max(y_max - y_min, 1e-12), max(e_max - e_min, 1e-12)
    a = np.column_stack(
        [
            (nsga["predicted_yield"] - y_min) / scale_y,
            (nsga["environmental_pressure"] - e_min) / scale_e,
        ]
    )
    b = np.column_stack(
        [
            (grid_front["predicted_yield"] - y_min) / scale_y,
            (grid_front["environmental_pressure"] - e_min) / scale_e,
        ]
    )
    d = np.sqrt(((a[:, None, :] - b[None, :, :]) ** 2).sum(axis=2)).min(axis=1)
    return {"median_normalized_distance": float(np.median(d)), "max_normalized_distance": float(np.max(d))}


def bootstrap_compromise_stability(
    bootstrap_models: list[FittedRegressor],
    representative: pd.Series,
    water_bounds: tuple[float, float],
    fertilizer_bounds: tuple[float, float],
) -> pd.DataFrame:
    rows = []
    for i, model in enumerate(bootstrap_models):
        grid = evaluate_grid(model, representative, water_bounds, fertilizer_bounds, 121, 121)
        grid["environmental_pressure"] = environmental_pressure(
            grid[WATER], grid[FERTILIZER], water_bounds, fertilizer_bounds, 0.5
        )
        front = nondominated_front(grid)
        point, _ = select_ideal_distance(front)
        rows.append({"bootstrap_model": i + 1, **point.to_dict()})
    return pd.DataFrame(rows)


def make_q4_figures(
    figure_dir: Path,
    grid: pd.DataFrame,
    front: pd.DataFrame,
    compromise: pd.Series,
    weighted: pd.DataFrame,
    nsga: pd.DataFrame,
    sensitivity: pd.DataFrame,
) -> None:
    figure_dir.mkdir(parents=True, exist_ok=True)
    plt.style.use("seaborn-v0_8-whitegrid")

    fig, ax = plt.subplots(figsize=(7.8, 5.4), constrained_layout=True)
    sample = grid.sample(min(12000, len(grid)), random_state=SEED)
    ax.scatter(sample["environmental_pressure"], sample["predicted_yield"], s=6, alpha=0.09, color="#777777", label="feasible grid")
    ax.plot(front["environmental_pressure"], front["predicted_yield"], color="#4C78A8", linewidth=2.1, label="dense-grid Pareto frontier")
    ax.scatter(nsga["environmental_pressure"], nsga["predicted_yield"], s=13, facecolors="none", edgecolors="#59A14F", alpha=0.8, label="NSGA-II comparator")
    ax.scatter(compromise["environmental_pressure"], compromise["predicted_yield"], marker="*", s=180, color="#E69F00", edgecolor="black", zorder=6, label="distance-to-ideal balance")
    ax.scatter(weighted["environmental_pressure"], weighted["predicted_yield"], s=22, color="#D55E00", alpha=0.7, label="weighted-sum points")
    ax.set_xlabel("Normalized environmental pressure index")
    ax.set_ylabel("Predicted yield (quintal/acre)")
    ax.set_title("Yield–environment tradeoff")
    ax.legend(fontsize=8)
    for ext in ("pdf", "png"):
        fig.savefig(figure_dir / f"q4_pareto_frontier.{ext}", dpi=320 if ext == "png" else None)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.2, 5.2), constrained_layout=True)
    scatter = ax.scatter(grid[WATER], grid[FERTILIZER], c=grid["environmental_pressure"], cmap="viridis", s=4, alpha=0.35)
    fig.colorbar(scatter, ax=ax, label="Environmental pressure")
    ax.plot(front[WATER], front[FERTILIZER], color="white", linewidth=1.4, alpha=0.9, label="Pareto decisions")
    ax.scatter(compromise[WATER], compromise[FERTILIZER], marker="*", s=180, color="#E69F00", edgecolor="black")
    ax.set_xlabel("Irrigation quantity (m³/acre; interpreted)")
    ax.set_ylabel("Fertilizer quantity (kg/acre)")
    ax.set_title("Decision-space location of the Pareto set")
    ax.legend()
    for ext in ("pdf", "png"):
        fig.savefig(figure_dir / f"q4_decision_space.{ext}", dpi=320 if ext == "png" else None)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.4, 4.7), constrained_layout=True)
    for weight, part in sensitivity.groupby("lambda_water"):
        ax.scatter(part["environmental_pressure"], part["predicted_yield"], s=75, label=f"water weight={weight:.1f}")
    ax.set_xlabel("Environmental pressure at selected balance")
    ax.set_ylabel("Predicted yield (quintal/acre)")
    ax.set_title("Environmental-weight sensitivity")
    ax.legend()
    for ext in ("pdf", "png"):
        fig.savefig(figure_dir / f"q4_weight_sensitivity.{ext}", dpi=320 if ext == "png" else None)
    plt.close(fig)


def run_q4(
    model: FittedRegressor,
    representative: pd.Series,
    water_bounds: tuple[float, float],
    fertilizer_bounds: tuple[float, float],
    bootstrap_models: list[FittedRegressor],
    output_dir: str | Path,
    figure_dir: str | Path,
) -> dict:
    output_dir = Path(output_dir)
    figure_dir = Path(figure_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)

    grid = evaluate_grid(model, representative, water_bounds, fertilizer_bounds, 351, 351)
    grid["environmental_pressure"] = environmental_pressure(
        grid[WATER], grid[FERTILIZER], water_bounds, fertilizer_bounds, 0.5
    )
    grid["economic_cost_rmb_ha_reference"] = economic_cost_per_hectare(
        grid[WATER], grid[FERTILIZER], BASE_WATER_PRICE, BASE_FERTILIZER_PRICE
    )
    front = nondominated_front(grid)
    compromise, audited_front = select_ideal_distance(front)
    weighted = weighted_sum_baseline(grid)
    nsga = nsga2_comparator(model, representative, water_bounds, fertilizer_bounds, 0.5)

    sensitivity_rows = []
    for lambda_water in (0.3, 0.5, 0.7):
        temp = grid.drop(columns=["environmental_pressure"]).copy()
        temp["environmental_pressure"] = environmental_pressure(
            temp[WATER], temp[FERTILIZER], water_bounds, fertilizer_bounds, lambda_water
        )
        temp_front = nondominated_front(temp)
        point, _ = select_ideal_distance(temp_front)
        sensitivity_rows.append({"lambda_water": lambda_water, **point.to_dict()})
    sensitivity = pd.DataFrame(sensitivity_rows)
    bootstrap_stability = bootstrap_compromise_stability(
        bootstrap_models, representative, water_bounds, fertilizer_bounds
    )

    # Report neighboring frontier choices around the selected point.
    selected_position = int(audited_front.index[audited_front.index == compromise.name][0])
    neighbor_positions = sorted(
        set(
            np.clip(
                [selected_position - 2, selected_position - 1, selected_position, selected_position + 1, selected_position + 2],
                0,
                len(audited_front) - 1,
            )
        )
    )
    neighbors = audited_front.iloc[neighbor_positions].copy()

    grid.to_csv(output_dir / "q4_dense_grid.csv", index=False, encoding="utf-8-sig")
    audited_front.to_csv(output_dir / "q4_pareto_frontier.csv", index=False, encoding="utf-8-sig")
    neighbors.to_csv(output_dir / "q4_neighboring_alternatives.csv", index=False, encoding="utf-8-sig")
    weighted.to_csv(output_dir / "q4_weighted_sum_baseline.csv", index=False, encoding="utf-8-sig")
    nsga.to_csv(output_dir / "q4_nsga2_comparator.csv", index=False, encoding="utf-8-sig")
    sensitivity.to_csv(output_dir / "q4_environment_weight_sensitivity.csv", index=False, encoding="utf-8-sig")
    bootstrap_stability.to_csv(output_dir / "q4_bootstrap_compromise_stability.csv", index=False, encoding="utf-8-sig")

    check_frame = candidate_frame(
        representative,
        model,
        np.array([compromise[WATER]]),
        np.array([compromise[FERTILIZER]]),
    )
    y_check = float(model.predict(check_frame)[0])
    e_check = float(
        environmental_pressure(
            compromise[WATER],
            compromise[FERTILIZER],
            water_bounds,
            fertilizer_bounds,
            0.5,
        )
    )
    domination_count = int(
        (
            (grid["predicted_yield"] >= compromise["predicted_yield"] - 1e-10)
            & (grid["environmental_pressure"] <= compromise["environmental_pressure"] + 1e-10)
            & (
                (grid["predicted_yield"] > compromise["predicted_yield"] + 1e-10)
                | (grid["environmental_pressure"] < compromise["environmental_pressure"] - 1e-10)
            )
        ).sum()
    )
    summary = {
        "random_seed": SEED,
        "environment_definition": "0.5*w_norm^2 + 0.5*f_norm^2 over training q05-q95 support",
        "economic_budget_applied": False,
        "reason_no_budget": "Question 4 replaces the economic objective with an environmental objective; only observed support bounds are retained",
        "frontier_points": len(audited_front),
        "compromise_rule": "minimum Euclidean distance to the ideal point after separate min-max normalization of yield loss and environmental pressure",
        "compromise": {k: float(v) for k, v in compromise.to_dict().items()},
        "compromise_cost_rmb_ha_reference": float(
            economic_cost_per_hectare(
                compromise[WATER], compromise[FERTILIZER], BASE_WATER_PRICE, BASE_FERTILIZER_PRICE
            )
        ),
        "independent_recalculation": {
            "predicted_yield": y_check,
            "environmental_pressure": e_check,
            "yield_abs_difference": abs(y_check - float(compromise["predicted_yield"])),
            "environment_abs_difference": abs(e_check - float(compromise["environmental_pressure"])),
            "number_of_strict_grid_dominators": domination_count,
        },
        "nsga2_comparison": frontier_distance(nsga, audited_front),
        "bootstrap_balance_intervals": {
            "water_2.5_97.5": [
                float(bootstrap_stability[WATER].quantile(0.025)),
                float(bootstrap_stability[WATER].quantile(0.975)),
            ],
            "fertilizer_2.5_97.5": [
                float(bootstrap_stability[FERTILIZER].quantile(0.025)),
                float(bootstrap_stability[FERTILIZER].quantile(0.975)),
            ],
        },
    }
    (output_dir / "q4_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    make_q4_figures(figure_dir, grid, audited_front, compromise, weighted, nsga, sensitivity)
    return {
        "grid": grid,
        "front": audited_front,
        "compromise": compromise,
        "sensitivity": sensitivity,
        "bootstrap_stability": bootstrap_stability,
        "summary": summary,
    }

