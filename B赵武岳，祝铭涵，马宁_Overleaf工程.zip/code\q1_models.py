"""Question 1: chronological model comparison and leakage-safe interpretation."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import time

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from catboost import CatBoostRegressor, Pool
from interpret.glassbox import ExplainableBoostingRegressor
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import ElasticNet
from sklearn.metrics import mean_absolute_error, r2_score, root_mean_squared_error
from sklearn.model_selection import GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from data_pipeline import (
    DECISION_SAFE_FEATURES,
    FULL_SEASON_FEATURES,
    SEED,
    TARGET,
    YEAR,
    TabularFiller,
    expanding_year_folds,
    numeric_and_categorical,
)


@dataclass
class FittedRegressor:
    name: str
    features: list[str]
    kind: str
    model: object | None = None
    filler: TabularFiller | None = None
    mean_value: float | None = None

    def predict(self, frame: pd.DataFrame) -> np.ndarray:
        if self.kind == "mean":
            return np.full(len(frame), float(self.mean_value), dtype=float)
        if self.kind == "elastic":
            return np.asarray(self.model.predict(frame[self.features]), dtype=float)
        if self.filler is None:
            raise RuntimeError("filler is required for EBM/CatBoost")
        x = self.filler.transform(frame)
        return np.asarray(self.model.predict(x[self.filler.ordered_features]), dtype=float)


def regression_metrics(y: np.ndarray, pred: np.ndarray) -> dict[str, float]:
    y = np.asarray(y, dtype=float)
    pred = np.asarray(pred, dtype=float)
    rmse = float(root_mean_squared_error(y, pred))
    return {
        "RMSE": rmse,
        "MAE": float(mean_absolute_error(y, pred)),
        "R2": float(r2_score(y, pred)),
        "NRMSE_mean": float(rmse / np.mean(y)),
        "MAPE_pct": float(np.mean(np.abs((y - pred) / np.clip(np.abs(y), 1e-8, None))) * 100),
        "bias": float(np.mean(pred - y)),
    }


def fit_mean(train: pd.DataFrame, features: list[str]) -> FittedRegressor:
    return FittedRegressor(
        name="Mean baseline",
        features=features,
        kind="mean",
        mean_value=float(train[TARGET].mean()),
    )


def elastic_pipeline(frame: pd.DataFrame, features: list[str], alpha: float, l1_ratio: float) -> Pipeline:
    numeric, categorical = numeric_and_categorical(frame, features)
    preprocess = ColumnTransformer(
        [
            (
                "numeric",
                Pipeline(
                    [
                        ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
                        ("scale", StandardScaler()),
                    ]
                ),
                numeric,
            ),
            (
                "categorical",
                Pipeline(
                    [
                        ("imputer", SimpleImputer(strategy="most_frequent")),
                        ("onehot", OneHotEncoder(handle_unknown="ignore")),
                    ]
                ),
                categorical,
            ),
        ],
        remainder="drop",
    )
    return Pipeline(
        [
            ("preprocess", preprocess),
            (
                "model",
                ElasticNet(
                    alpha=alpha,
                    l1_ratio=l1_ratio,
                    max_iter=30000,
                    tol=1e-4,
                    random_state=SEED,
                    selection="cyclic",
                ),
            ),
        ]
    )


def tune_elastic(train: pd.DataFrame, features: list[str]) -> tuple[float, float, pd.DataFrame]:
    base = elastic_pipeline(train, features, alpha=0.1, l1_ratio=0.5)
    folds = [(tr, va) for tr, va, _ in expanding_year_folds(train)]
    search = GridSearchCV(
        base,
        param_grid={
            "model__alpha": [0.01, 0.05, 0.1, 0.5, 1.0, 5.0, 10.0],
            "model__l1_ratio": [0.05, 0.25, 0.5, 0.75, 0.95],
        },
        scoring="neg_root_mean_squared_error",
        cv=folds,
        n_jobs=-1,
        refit=False,
        error_score="raise",
    )
    search.fit(train[features], train[TARGET])
    result = pd.DataFrame(search.cv_results_).sort_values("rank_test_score")
    best = result.iloc[0]
    return (
        float(best["param_model__alpha"]),
        float(best["param_model__l1_ratio"]),
        result,
    )


def fit_elastic(train: pd.DataFrame, features: list[str], alpha: float, l1_ratio: float) -> FittedRegressor:
    pipe = elastic_pipeline(train, features, alpha=alpha, l1_ratio=l1_ratio)
    pipe.fit(train[features], train[TARGET])
    return FittedRegressor("Elastic Net", features, "elastic", model=pipe)


def fit_ebm(train: pd.DataFrame, features: list[str], interactions: int = 10) -> FittedRegressor:
    filler = TabularFiller.fit(train, features)
    x = filler.transform(train)
    model = ExplainableBoostingRegressor(
        feature_names=filler.ordered_features,
        feature_types=filler.feature_types,
        interactions=interactions,
        max_bins=128,
        max_interaction_bins=32,
        validation_size=0.15,
        outer_bags=8,
        learning_rate=0.04,
        max_rounds=3000,
        early_stopping_rounds=100,
        min_samples_leaf=8,
        n_jobs=-1,
        random_state=SEED,
    )
    model.fit(x[filler.ordered_features], train[TARGET].to_numpy())
    return FittedRegressor("EBM", features, "ebm", model=model, filler=filler)


def fit_catboost(
    train: pd.DataFrame,
    features: list[str],
    iterations: int = 800,
    depth: int = 6,
    seed: int = SEED,
) -> FittedRegressor:
    filler = TabularFiller.fit(train, features)
    x = filler.transform(train)
    cat_idx = [x.columns.get_loc(c) for c in filler.categorical]
    model = CatBoostRegressor(
        loss_function="RMSE",
        iterations=iterations,
        depth=depth,
        learning_rate=0.035,
        l2_leaf_reg=5.0,
        random_seed=seed,
        random_strength=0.4,
        bagging_temperature=0.4,
        verbose=False,
        thread_count=-1,
        allow_writing_files=False,
    )
    model.fit(x[filler.ordered_features], train[TARGET], cat_features=cat_idx, verbose=False)
    return FittedRegressor("CatBoost", features, "catboost", model=model, filler=filler)


def cross_validate_candidate(
    candidate: str,
    train: pd.DataFrame,
    features: list[str],
    elastic_params: tuple[float, float],
) -> pd.DataFrame:
    rows: list[dict] = []
    for tr_idx, va_idx, year in expanding_year_folds(train):
        tr, va = train.iloc[tr_idx], train.iloc[va_idx]
        started = time.perf_counter()
        if candidate == "Mean baseline":
            fitted = fit_mean(tr, features)
        elif candidate == "Elastic Net":
            fitted = fit_elastic(tr, features, *elastic_params)
        elif candidate == "EBM":
            fitted = fit_ebm(tr, features)
        elif candidate == "CatBoost":
            fitted = fit_catboost(tr, features, iterations=600)
        else:
            raise ValueError(candidate)
        metrics = regression_metrics(va[TARGET].to_numpy(), fitted.predict(va))
        rows.append(
            {
                "model": candidate,
                "validation_year": year,
                "train_n": len(tr),
                "validation_n": len(va),
                "runtime_seconds": time.perf_counter() - started,
                **metrics,
            }
        )
    return pd.DataFrame(rows)


def bootstrap_metric_intervals(y: np.ndarray, pred: np.ndarray, n_boot: int = 1000) -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    rows = []
    n = len(y)
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        rows.append(regression_metrics(y[idx], pred[idx]))
    values = pd.DataFrame(rows)
    return pd.DataFrame(
        {
            "metric": values.columns,
            "estimate": [regression_metrics(y, pred)[c] for c in values.columns],
            "ci_2.5": values.quantile(0.025).to_numpy(),
            "ci_97.5": values.quantile(0.975).to_numpy(),
        }
    )


def permutation_importance_raw(
    fitted: FittedRegressor,
    validation: pd.DataFrame,
    repeats: int = 20,
) -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    y = validation[TARGET].to_numpy()
    base_rmse = root_mean_squared_error(y, fitted.predict(validation))
    rows: list[dict] = []
    for feature in fitted.features:
        changes = []
        for _ in range(repeats):
            altered = validation.copy()
            altered[feature] = rng.permutation(altered[feature].to_numpy())
            changes.append(root_mean_squared_error(y, fitted.predict(altered)) - base_rmse)
        rows.append(
            {
                "feature": feature,
                "rmse_increase_mean": float(np.mean(changes)),
                "rmse_increase_sd": float(np.std(changes, ddof=1)),
                "positive_repeat_rate": float(np.mean(np.asarray(changes) > 0)),
            }
        )
    return pd.DataFrame(rows).sort_values("rmse_increase_mean", ascending=False)


def marginal_effects(
    fitted: FittedRegressor,
    train: pd.DataFrame,
    reference: pd.DataFrame,
    features: list[str],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(SEED)
    base = reference.sample(min(600, len(reference)), random_state=SEED).copy()
    summaries: list[dict] = []
    curves: list[dict] = []
    for feature in features:
        if pd.api.types.is_numeric_dtype(train[feature]):
            q10, q90 = train[feature].quantile([0.10, 0.90]).astype(float)
            low = base.copy()
            high = base.copy()
            low[feature], high[feature] = q10, q90
            delta_rows = fitted.predict(high) - fitted.predict(low)
            boot = []
            for _ in range(300):
                idx = rng.integers(0, len(delta_rows), len(delta_rows))
                boot.append(float(np.mean(delta_rows[idx])))
            summaries.append(
                {
                    "feature": feature,
                    "contrast": "q90_minus_q10",
                    "low_value": q10,
                    "high_value": q90,
                    "mean_prediction_change": float(np.mean(delta_rows)),
                    "ci_2.5": float(np.quantile(boot, 0.025)),
                    "ci_97.5": float(np.quantile(boot, 0.975)),
                    "direction": "positive" if np.mean(delta_rows) > 0 else "negative",
                }
            )
            grid = np.unique(train[feature].quantile(np.linspace(0.05, 0.95, 25)).dropna())
            for value in grid:
                changed = base.copy()
                changed[feature] = float(value)
                p = fitted.predict(changed)
                curves.append(
                    {
                        "feature": feature,
                        "value": float(value),
                        "prediction_mean": float(np.mean(p)),
                        "prediction_se": float(np.std(p, ddof=1) / np.sqrt(len(p))),
                    }
                )
        else:
            levels = train[feature].dropna().astype(str).value_counts().head(8).index.tolist()
            if len(levels) < 2:
                continue
            level_predictions = {}
            for level in levels:
                changed = base.copy()
                changed[feature] = level
                level_predictions[level] = float(np.mean(fitted.predict(changed)))
            low_level = min(level_predictions, key=level_predictions.get)
            high_level = max(level_predictions, key=level_predictions.get)
            summaries.append(
                {
                    "feature": feature,
                    "contrast": f"{high_level}_minus_{low_level}",
                    "low_value": low_level,
                    "high_value": high_level,
                    "mean_prediction_change": level_predictions[high_level] - level_predictions[low_level],
                    "ci_2.5": np.nan,
                    "ci_97.5": np.nan,
                    "direction": "category contrast",
                }
            )
    return pd.DataFrame(summaries), pd.DataFrame(curves)


def group_error_table(data: pd.DataFrame, pred: np.ndarray) -> pd.DataFrame:
    temp = data[[TARGET, "Variety", "Season", YEAR]].copy()
    temp["prediction"] = pred
    temp["residual"] = temp[TARGET] - temp["prediction"]
    rows = []
    for group_col in [YEAR, "Variety", "Season"]:
        for value, part in temp.groupby(group_col, dropna=False):
            m = regression_metrics(part[TARGET].to_numpy(), part["prediction"].to_numpy())
            rows.append({"grouping": group_col, "group": str(value), "n": len(part), **m})
    return pd.DataFrame(rows)


def save_ebm_importance(fitted: FittedRegressor, path: Path) -> None:
    if fitted.kind != "ebm":
        return
    data = fitted.model.explain_global().data()
    pd.DataFrame(
        {
            "term": data["names"],
            "importance": data["scores"],
        }
    ).sort_values("importance", ascending=False).to_csv(path, index=False, encoding="utf-8-sig")


def save_catboost_shap(fitted: FittedRegressor, validation: pd.DataFrame, path: Path) -> None:
    if fitted.kind != "catboost":
        return
    sample = validation.sample(min(800, len(validation)), random_state=SEED)
    x = fitted.filler.transform(sample)
    cat_idx = [x.columns.get_loc(c) for c in fitted.filler.categorical]
    pool = Pool(x[fitted.filler.ordered_features], cat_features=cat_idx)
    values = fitted.model.get_feature_importance(pool, type="ShapValues")[:, :-1]
    pd.DataFrame(
        {
            "feature": fitted.filler.ordered_features,
            "mean_abs_shap": np.abs(values).mean(axis=0),
            "mean_shap": values.mean(axis=0),
        }
    ).sort_values("mean_abs_shap", ascending=False).to_csv(path, index=False, encoding="utf-8-sig")


def make_q1_figures(
    output_dir: Path,
    metrics: pd.DataFrame,
    validation: pd.DataFrame,
    predictions: dict[str, np.ndarray],
    importance: pd.DataFrame,
    curves: pd.DataFrame,
    selected_name: str,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    plt.style.use("seaborn-v0_8-whitegrid")

    val = metrics[(metrics["split"] == "2023_validation") & (~metrics["model"].str.contains("auxiliary"))]
    fig, axes = plt.subplots(1, 2, figsize=(10.2, 4.1), constrained_layout=True)
    axes[0].bar(val["model"], val["RMSE"], color=["#999999", "#4C78A8", "#59A14F", "#F28E2B"])
    axes[0].set_ylabel("RMSE (quintal/acre)")
    axes[0].set_title("Chronological validation: 2023")
    axes[0].tick_params(axis="x", rotation=20)
    axes[1].bar(val["model"], val["R2"], color=["#999999", "#4C78A8", "#59A14F", "#F28E2B"])
    axes[1].axhline(0, color="black", linewidth=0.8)
    axes[1].set_ylabel("R²")
    axes[1].set_title("Out-of-time explanatory power")
    axes[1].tick_params(axis="x", rotation=20)
    for ext in ("pdf", "png"):
        fig.savefig(output_dir / f"q1_model_comparison.{ext}", dpi=320 if ext == "png" else None)
    plt.close(fig)

    y = validation[TARGET].to_numpy()
    pred = predictions[selected_name]
    residual = y - pred
    fig, axes = plt.subplots(1, 2, figsize=(10.2, 4.2), constrained_layout=True)
    axes[0].scatter(y, pred, s=13, alpha=0.55, color="#4C78A8", edgecolors="none")
    lo, hi = min(y.min(), pred.min()), max(y.max(), pred.max())
    axes[0].plot([lo, hi], [lo, hi], color="#C44E52", linewidth=1.2)
    axes[0].set_xlabel("Observed yield (quintal/acre)")
    axes[0].set_ylabel("Predicted yield (quintal/acre)")
    axes[0].set_title(f"{selected_name}: observed vs predicted")
    axes[1].scatter(pred, residual, s=13, alpha=0.55, color="#59A14F", edgecolors="none")
    axes[1].axhline(0, color="#C44E52", linewidth=1.1)
    axes[1].set_xlabel("Predicted yield (quintal/acre)")
    axes[1].set_ylabel("Residual (observed - predicted)")
    axes[1].set_title("Residual diagnostic")
    for ext in ("pdf", "png"):
        fig.savefig(output_dir / f"q1_validation_diagnostics.{ext}", dpi=320 if ext == "png" else None)
    plt.close(fig)

    top = importance.head(12).sort_values("rmse_increase_mean")
    fig, ax = plt.subplots(figsize=(7.4, 5.1), constrained_layout=True)
    ax.barh(top["feature"], top["rmse_increase_mean"], color="#4C78A8")
    ax.errorbar(
        top["rmse_increase_mean"],
        np.arange(len(top)),
        xerr=top["rmse_increase_sd"],
        fmt="none",
        ecolor="#2F2F2F",
        capsize=2,
    )
    ax.set_xlabel("Increase in 2023 RMSE after permutation")
    ax.set_title("Leakage-safe predictive importance")
    for ext in ("pdf", "png"):
        fig.savefig(output_dir / f"q1_permutation_importance.{ext}", dpi=320 if ext == "png" else None)
    plt.close(fig)

    available = [f for f in importance["feature"].tolist() if f in set(curves["feature"])]
    chosen = available[:4]
    if chosen:
        fig, axes = plt.subplots(2, 2, figsize=(10.2, 7.3), constrained_layout=True)
        for ax, feature in zip(axes.ravel(), chosen):
            part = curves[curves["feature"] == feature].sort_values("value")
            ax.plot(part["value"], part["prediction_mean"], color="#4C78A8", linewidth=1.8)
            band = 1.96 * part["prediction_se"]
            ax.fill_between(
                part["value"],
                part["prediction_mean"] - band,
                part["prediction_mean"] + band,
                color="#4C78A8",
                alpha=0.18,
            )
            ax.set_title(feature)
            ax.set_ylabel("Average predicted yield")
        for ax in axes.ravel()[len(chosen):]:
            ax.axis("off")
        for ext in ("pdf", "png"):
            fig.savefig(output_dir / f"q1_effect_curves.{ext}", dpi=320 if ext == "png" else None)
        plt.close(fig)


def run_q1(
    df: pd.DataFrame,
    output_dir: str | Path,
    model_dir: str | Path,
    figure_dir: str | Path,
) -> dict:
    output_dir = Path(output_dir)
    model_dir = Path(model_dir)
    figure_dir = Path(figure_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    model_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)

    known = df[df[YEAR].notna()].copy()
    train = known[known[YEAR].between(2018, 2022, inclusive="both")].copy()
    validation = known[known[YEAR].eq(2023)].copy()
    test = known[known[YEAR].eq(2024)].copy()
    train_validation = known[known[YEAR].between(2018, 2023, inclusive="both")].copy()
    features = [c for c in DECISION_SAFE_FEATURES if c in df.columns]

    alpha, l1_ratio, elastic_search = tune_elastic(train, features)
    elastic_search.to_csv(output_dir / "elastic_net_tuning.csv", index=False, encoding="utf-8-sig")

    cv = pd.concat(
        [
            cross_validate_candidate(name, train, features, (alpha, l1_ratio))
            for name in ["Mean baseline", "Elastic Net", "EBM", "CatBoost"]
        ],
        ignore_index=True,
    )
    cv.to_csv(output_dir / "chronological_cv_metrics.csv", index=False, encoding="utf-8-sig")

    fitted_train = {
        "Mean baseline": fit_mean(train, features),
        "Elastic Net": fit_elastic(train, features, alpha, l1_ratio),
        "EBM": fit_ebm(train, features),
        "CatBoost": fit_catboost(train, features),
    }
    metric_rows = []
    predictions = {}
    for name, fitted in fitted_train.items():
        for split_name, split in [("2023_validation", validation), ("2024_test_locked", test)]:
            pred = fitted.predict(split)
            if split_name == "2023_validation":
                predictions[name] = pred
            metric_rows.append({"model": name, "split": split_name, "n": len(split), **regression_metrics(split[TARGET], pred)})

    full_features = [c for c in FULL_SEASON_FEATURES if c in df.columns]
    auxiliary = fit_catboost(train, full_features, iterations=800)
    for split_name, split in [("2023_validation", validation), ("2024_test_locked", test)]:
        pred = auxiliary.predict(split)
        metric_rows.append(
            {
                "model": "CatBoost full-season auxiliary (not decision-safe)",
                "split": split_name,
                "n": len(split),
                **regression_metrics(split[TARGET], pred),
            }
        )

    metrics = pd.DataFrame(metric_rows)
    metrics.to_csv(output_dir / "holdout_metrics.csv", index=False, encoding="utf-8-sig")

    val_metrics = metrics[metrics["split"] == "2023_validation"].set_index("model")
    elastic_rmse = float(val_metrics.loc["Elastic Net", "RMSE"])
    ebm_rmse = float(val_metrics.loc["EBM", "RMSE"])
    cat_rmse = float(val_metrics.loc["CatBoost", "RMSE"])
    relative_gain = (ebm_rmse - cat_rmse) / ebm_rmse
    best_complex_name = "CatBoost" if cat_rmse <= ebm_rmse else "EBM"
    best_complex_rmse = min(cat_rmse, ebm_rmse)
    complex_gain_vs_elastic = (elastic_rmse - best_complex_rmse) / elastic_rmse
    # Complexity is retained only when it yields a material chronological gain.
    # Otherwise the auditable linear baseline becomes the practical main model.
    selected_name = best_complex_name if complex_gain_vs_elastic >= 0.05 else "Elastic Net"
    selected_train = fitted_train[selected_name]

    # Refit through 2023 only after selection; 2024 remains the locked audit set.
    if selected_name == "CatBoost":
        selected_deployment = fit_catboost(train_validation, features, iterations=900)
    elif selected_name == "EBM":
        selected_deployment = fit_ebm(train_validation, features)
    else:
        selected_deployment = fit_elastic(train_validation, features, alpha, l1_ratio)
    final_test_pred = selected_deployment.predict(test)
    final_test_metrics = regression_metrics(test[TARGET], final_test_pred)

    joblib.dump(selected_train, model_dir / "selected_model_train_2018_2022.joblib")
    joblib.dump(selected_deployment, model_dir / "selected_model_train_2018_2023.joblib")
    joblib.dump(fitted_train["EBM"], model_dir / "ebm_train_2018_2022.joblib")
    joblib.dump(fitted_train["CatBoost"], model_dir / "catboost_train_2018_2022.joblib")

    selected_val_pred = selected_train.predict(validation)
    pd.DataFrame(
        {
            "source_index": validation.index,
            "year": validation[YEAR].to_numpy(),
            "observed": validation[TARGET].to_numpy(),
            "predicted": selected_val_pred,
            "residual": validation[TARGET].to_numpy() - selected_val_pred,
        }
    ).to_csv(output_dir / "selected_model_2023_predictions.csv", index=False, encoding="utf-8-sig")

    intervals = bootstrap_metric_intervals(validation[TARGET].to_numpy(), selected_val_pred)
    intervals.to_csv(output_dir / "selected_model_metric_intervals.csv", index=False, encoding="utf-8-sig")
    group_error_table(validation, selected_val_pred).to_csv(
        output_dir / "selected_model_subgroup_errors.csv", index=False, encoding="utf-8-sig"
    )

    importance = permutation_importance_raw(selected_train, validation)
    importance.to_csv(output_dir / "selected_model_permutation_importance.csv", index=False, encoding="utf-8-sig")
    top_effect_features = importance.head(15)["feature"].tolist()
    effect_summary, effect_curves = marginal_effects(
        selected_train, train, validation, top_effect_features
    )
    effect_summary.to_csv(output_dir / "selected_model_effect_directions.csv", index=False, encoding="utf-8-sig")
    effect_curves.to_csv(output_dir / "selected_model_effect_curves.csv", index=False, encoding="utf-8-sig")

    save_ebm_importance(fitted_train["EBM"], output_dir / "ebm_global_importance.csv")
    save_catboost_shap(fitted_train["CatBoost"], validation, output_dir / "catboost_shap_importance.csv")

    make_q1_figures(
        figure_dir,
        metrics,
        validation,
        predictions,
        importance,
        effect_curves,
        selected_name,
    )

    residual = validation[TARGET].to_numpy() - selected_val_pred
    heteroscedasticity_proxy = float(
        pd.Series(np.abs(residual)).corr(pd.Series(selected_val_pred), method="spearman")
    )
    summary = {
        "random_seed": SEED,
        "features_decision_safe": len(features),
        "train_n_2018_2022": len(train),
        "validation_n_2023": len(validation),
        "test_n_2024": len(test),
        "elastic_alpha": alpha,
        "elastic_l1_ratio": l1_ratio,
        "selected_model": selected_name,
        "catboost_relative_rmse_gain_vs_ebm_2023": relative_gain,
        "best_complex_relative_rmse_gain_vs_elastic_2023": complex_gain_vs_elastic,
        "selected_2023_metrics": regression_metrics(validation[TARGET], selected_val_pred),
        "selected_refit_2018_2023_locked_2024_metrics": final_test_metrics,
        "abs_residual_vs_prediction_spearman": heteroscedasticity_proxy,
        "decision_model_quality_gate_passed": bool(
            regression_metrics(validation[TARGET], selected_val_pred)["R2"] >= 0.30
        ),
        "selection_rule": "Select the best of EBM/CatBoost only if it improves 2023 RMSE by at least 5% over Elastic Net; otherwise retain Elastic Net",
    }
    (output_dir / "q1_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return {
        "summary": summary,
        "selected_model": selected_deployment,
        "train": train,
        "validation": validation,
        "test": test,
        "train_validation": train_validation,
    }
