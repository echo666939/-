"""Question 2: representative plot and budget-constrained water/fertilizer optimization."""

from __future__ import annotations

from pathlib import Path
import json

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from sklearn.metrics import pairwise_distances

from data_pipeline import (
    FERTILIZER,
    REPRESENTATIVE_FEATURES,
    SEED,
    TARGET,
    WATER,
    YEAR,
    economic_cost_per_hectare,
    training_support,
)
from q1_models import FittedRegressor, fit_catboost


BASE_WATER_PRICE = 0.20
BASE_FERTILIZER_PRICE = 3.00
BASE_BUDGET = 2500.0


def gower_medoid(train: pd.DataFrame) -> tuple[int, pd.DataFrame]:
    """Find the real observation minimizing mean Gower distance."""

    features = [c for c in REPRESENTATIVE_FEATURES if c in train.columns]
    numeric = [c for c in features if pd.api.types.is_numeric_dtype(train[c])]
    categorical = [c for c in features if c not in numeric]
    distance = np.zeros((len(train), len(train)), dtype=np.float32)

    if numeric:
        x = train[numeric].copy()
        for c in numeric:
            s = pd.to_numeric(x[c], errors="coerce")
            med = float(s.median())
            lo, hi = s.quantile([0.05, 0.95]).astype(float)
            denom = max(hi - lo, 1e-12)
            x[c] = (s.fillna(med).clip(lo, hi) - lo) / denom
        distance += pairwise_distances(x.to_numpy(), metric="manhattan").astype(np.float32)

    for c in categorical:
        s = train[c].astype("string")
        mode = s.mode(dropna=True)
        fill = str(mode.iloc[0]) if len(mode) else "__MISSING__"
        codes, _ = pd.factorize(s.fillna(fill), sort=True)
        distance += (codes[:, None] != codes[None, :]).astype(np.float32)

    distance /= max(len(features), 1)
    mean_distance = distance.mean(axis=1)
    position = int(np.argmin(mean_distance))
    diagnostics = pd.DataFrame(
        {
            "source_index": train.index.to_numpy(),
            "mean_gower_distance": mean_distance,
        }
    ).sort_values("mean_gower_distance")
    return int(train.index[position]), diagnostics


def candidate_frame(
    representative: pd.Series,
    model: FittedRegressor,
    water: np.ndarray,
    fertilizer: np.ndarray,
) -> pd.DataFrame:
    n = len(water)
    base = pd.DataFrame(
        np.tile(representative[model.features].to_numpy(dtype=object), (n, 1)),
        columns=model.features,
    )
    # Restore numeric columns after object tiling; model filler will validate them again.
    for c in model.features:
        if pd.api.types.is_numeric_dtype(type(representative[c])):
            base[c] = pd.to_numeric(base[c], errors="coerce")
    base[WATER] = np.asarray(water, dtype=float)
    base[FERTILIZER] = np.asarray(fertilizer, dtype=float)
    return base


def evaluate_grid(
    model: FittedRegressor,
    representative: pd.Series,
    water_bounds: tuple[float, float],
    fertilizer_bounds: tuple[float, float],
    n_water: int,
    n_fertilizer: int,
) -> pd.DataFrame:
    water_values = np.linspace(*water_bounds, n_water)
    fertilizer_values = np.linspace(*fertilizer_bounds, n_fertilizer)
    w, f = np.meshgrid(water_values, fertilizer_values, indexing="xy")
    flat_w, flat_f = w.ravel(), f.ravel()
    frame = candidate_frame(representative, model, flat_w, flat_f)
    pred = model.predict(frame)
    return pd.DataFrame({WATER: flat_w, FERTILIZER: flat_f, "predicted_yield": pred})


def choose_budget_optimum(
    grid: pd.DataFrame,
    water_price: float,
    fertilizer_price: float,
    budget: float,
) -> pd.Series:
    work = grid.copy()
    work["cost_rmb_per_ha"] = economic_cost_per_hectare(
        work[WATER], work[FERTILIZER], water_price, fertilizer_price
    )
    feasible = work[work["cost_rmb_per_ha"] <= budget + 1e-9].copy()
    if feasible.empty:
        raise RuntimeError("No feasible water/fertilizer combination under the confirmed budget")
    feasible = feasible.sort_values(
        ["predicted_yield", "cost_rmb_per_ha"], ascending=[False, True]
    )
    return feasible.iloc[0]


def local_refinement(
    model: FittedRegressor,
    representative: pd.Series,
    start: pd.Series,
    water_bounds: tuple[float, float],
    fertilizer_bounds: tuple[float, float],
    water_price: float,
    fertilizer_price: float,
    budget: float,
) -> dict[str, float]:
    scale_w = water_bounds[1] - water_bounds[0]
    scale_f = fertilizer_bounds[1] - fertilizer_bounds[0]

    def objective(z: np.ndarray) -> float:
        w = water_bounds[0] + np.clip(z[0], 0, 1) * scale_w
        f = fertilizer_bounds[0] + np.clip(z[1], 0, 1) * scale_f
        cost = float(economic_cost_per_hectare(w, f, water_price, fertilizer_price))
        penalty = 50.0 * max(0.0, (cost - budget) / max(budget, 1.0)) ** 2
        frame = candidate_frame(representative, model, np.array([w]), np.array([f]))
        return -float(model.predict(frame)[0]) + penalty

    z0 = np.array(
        [
            (float(start[WATER]) - water_bounds[0]) / scale_w,
            (float(start[FERTILIZER]) - fertilizer_bounds[0]) / scale_f,
        ]
    )
    result = minimize(
        objective,
        z0,
        method="Nelder-Mead",
        options={"maxiter": 500, "xatol": 1e-6, "fatol": 1e-5},
    )
    z = np.clip(result.x, 0, 1)
    w = water_bounds[0] + z[0] * scale_w
    f = fertilizer_bounds[0] + z[1] * scale_f
    cost = float(economic_cost_per_hectare(w, f, water_price, fertilizer_price))
    if cost > budget + 1e-6:
        return {
            "water": float(start[WATER]),
            "fertilizer": float(start[FERTILIZER]),
            "predicted_yield": float(start["predicted_yield"]),
            "cost": float(start["cost_rmb_per_ha"]),
            "success": False,
            "message": "local search returned infeasible point; dense-grid optimum retained",
        }
    frame = candidate_frame(representative, model, np.array([w]), np.array([f]))
    pred = float(model.predict(frame)[0])
    if pred + 1e-9 < float(start["predicted_yield"]):
        return {
            "water": float(start[WATER]),
            "fertilizer": float(start[FERTILIZER]),
            "predicted_yield": float(start["predicted_yield"]),
            "cost": float(start["cost_rmb_per_ha"]),
            "success": False,
            "message": "local search did not improve dense-grid optimum",
        }
    return {
        "water": float(w),
        "fertilizer": float(f),
        "predicted_yield": pred,
        "cost": cost,
        "success": bool(result.success),
        "message": str(result.message),
    }


def fit_bootstrap_models(
    train_validation: pd.DataFrame,
    features: list[str],
    n_models: int = 20,
) -> list[FittedRegressor]:
    rng = np.random.default_rng(SEED)
    models: list[FittedRegressor] = []
    years = sorted(int(y) for y in train_validation[YEAR].dropna().unique())
    for b in range(n_models):
        pieces = []
        for year in years:
            part = train_validation[train_validation[YEAR] == year]
            idx = rng.integers(0, len(part), len(part))
            pieces.append(part.iloc[idx])
        sample = pd.concat(pieces, ignore_index=True)
        models.append(fit_catboost(sample, features, iterations=350, depth=5, seed=SEED + b + 1))
    return models


def robust_optimum(
    bootstrap_models: list[FittedRegressor],
    representative: pd.Series,
    water_bounds: tuple[float, float],
    fertilizer_bounds: tuple[float, float],
    water_price: float,
    fertilizer_price: float,
    budget: float,
) -> tuple[pd.Series, pd.DataFrame]:
    water_values = np.linspace(*water_bounds, 151)
    fertilizer_values = np.linspace(*fertilizer_bounds, 151)
    w, f = np.meshgrid(water_values, fertilizer_values, indexing="xy")
    flat_w, flat_f = w.ravel(), f.ravel()
    frame = candidate_frame(representative, bootstrap_models[0], flat_w, flat_f)
    predictions = np.vstack([m.predict(frame) for m in bootstrap_models])
    table = pd.DataFrame(
        {
            WATER: flat_w,
            FERTILIZER: flat_f,
            "prediction_mean": predictions.mean(axis=0),
            "prediction_q10": np.quantile(predictions, 0.10, axis=0),
            "prediction_sd": predictions.std(axis=0, ddof=1),
        }
    )
    table["cost_rmb_per_ha"] = economic_cost_per_hectare(
        table[WATER], table[FERTILIZER], water_price, fertilizer_price
    )
    feasible = table[table["cost_rmb_per_ha"] <= budget + 1e-9].copy()
    optimum = feasible.sort_values(
        ["prediction_q10", "prediction_mean", "cost_rmb_per_ha"],
        ascending=[False, False, True],
    ).iloc[0]
    return optimum, table


def decision_effect_stability(
    models: list[FittedRegressor],
    representative: pd.Series,
    water_bounds: tuple[float, float],
    fertilizer_bounds: tuple[float, float],
) -> pd.DataFrame:
    """Check whether water/fertilizer directions agree across bootstrap models."""

    w_mid = float(np.mean(water_bounds))
    f_mid = float(np.mean(fertilizer_bounds))
    rows = []
    for i, fitted in enumerate(models):
        water_frame = candidate_frame(
            representative,
            fitted,
            np.array([water_bounds[0], water_bounds[1]]),
            np.array([f_mid, f_mid]),
        )
        fertilizer_frame = candidate_frame(
            representative,
            fitted,
            np.array([w_mid, w_mid]),
            np.array([fertilizer_bounds[0], fertilizer_bounds[1]]),
        )
        water_prediction = fitted.predict(water_frame)
        fertilizer_prediction = fitted.predict(fertilizer_frame)
        rows.append(
            {
                "bootstrap_model": i + 1,
                "water_high_minus_low_yield": float(water_prediction[1] - water_prediction[0]),
                "fertilizer_high_minus_low_yield": float(fertilizer_prediction[1] - fertilizer_prediction[0]),
            }
        )
    return pd.DataFrame(rows)


def make_q2_figures(
    figure_dir: Path,
    dense: pd.DataFrame,
    baseline_optimum: pd.Series,
    main_optimum: pd.Series,
    robust: pd.DataFrame,
    robust_opt: pd.Series,
    support: dict[str, tuple[float, float]],
    effect_stability: pd.DataFrame | None = None,
) -> None:
    figure_dir.mkdir(parents=True, exist_ok=True)
    plt.style.use("seaborn-v0_8-whitegrid")
    n = int(round(np.sqrt(len(dense))))
    w = dense[WATER].to_numpy().reshape(n, n)
    f = dense[FERTILIZER].to_numpy().reshape(n, n)
    y = dense["predicted_yield"].to_numpy().reshape(n, n)
    cost = economic_cost_per_hectare(w, f, BASE_WATER_PRICE, BASE_FERTILIZER_PRICE)
    masked = np.ma.masked_where(cost > BASE_BUDGET, y)
    fig, ax = plt.subplots(figsize=(7.4, 5.6), constrained_layout=True)
    mesh = ax.pcolormesh(w, f, masked, shading="auto", cmap="viridis")
    fig.colorbar(mesh, ax=ax, label="Predicted yield (quintal/acre)")
    ax.contour(w, f, cost, levels=[BASE_BUDGET], colors="#D55E00", linewidths=1.4)
    ax.scatter(baseline_optimum[WATER], baseline_optimum[FERTILIZER], marker="o", s=45, color="white", edgecolor="black", label="101×101 baseline")
    ax.scatter(main_optimum[WATER], main_optimum[FERTILIZER], marker="*", s=170, color="#E69F00", edgecolor="black", zorder=6, label="main optimum")
    ax.set_xlabel("Irrigation quantity (m³/acre; interpreted)")
    ax.set_ylabel("Fertilizer quantity (kg/acre)")
    ax.set_xlim(w.min() - 0.025 * (w.max() - w.min()), w.max() + 0.025 * (w.max() - w.min()))
    ax.set_ylim(f.min() - 0.025 * (f.max() - f.min()), f.max() + 0.025 * (f.max() - f.min()))
    ax.set_title("Budget-feasible response surface")
    ax.legend(frameon=True)
    for ext in ("pdf", "png"):
        fig.savefig(figure_dir / f"q2_response_surface.{ext}", dpi=320 if ext == "png" else None)
    plt.close(fig)

    near = robust.nsmallest(2500, columns="prediction_q10").copy()
    # Display the upper part of the robust candidate set rather than a decorative distribution.
    threshold = robust["prediction_q10"].quantile(0.90)
    near = robust[robust["prediction_q10"] >= threshold]
    fig, ax = plt.subplots(figsize=(7.4, 5.3), constrained_layout=True)
    scatter = ax.scatter(
        near[WATER], near[FERTILIZER], c=near["prediction_q10"], cmap="cividis", s=16, alpha=0.75
    )
    fig.colorbar(scatter, ax=ax, label="10th-percentile predicted yield")
    ax.scatter(robust_opt[WATER], robust_opt[FERTILIZER], marker="*", s=160, color="#D55E00", edgecolor="black")
    ax.set_xlabel("Irrigation quantity (m³/acre; interpreted)")
    ax.set_ylabel("Fertilizer quantity (kg/acre)")
    ax.set_title("Bootstrap lower-bound robust optimum")
    for ext in ("pdf", "png"):
        fig.savefig(figure_dir / f"q2_robust_optimum.{ext}", dpi=320 if ext == "png" else None)
    plt.close(fig)

    if effect_stability is not None and not effect_stability.empty:
        stability = effect_stability.sort_values("bootstrap_model").reset_index(drop=True)
        fig, axes = plt.subplots(1, 2, figsize=(10.2, 4.5), sharey=True, constrained_layout=True)
        panels = [
            ("water_high_minus_low_yield", "Water: high minus low support", "#4C78A8"),
            ("fertilizer_high_minus_low_yield", "Fertilizer: high minus low support", "#F28E2B"),
        ]
        y_positions = np.arange(1, len(stability) + 1)
        for ax, (column, title, color) in zip(axes, panels):
            values = stability[column].to_numpy(dtype=float)
            ax.axvline(0, color="#333333", linewidth=1.0)
            ax.hlines(y_positions, 0, values, color=color, alpha=0.55, linewidth=1.4)
            ax.scatter(values, y_positions, color=color, edgecolor="white", linewidth=0.5, s=42, zorder=3)
            positive_rate = float(np.mean(values > 0))
            ax.set_title(f"{title}\npositive in {positive_rate:.0%} of models")
            ax.set_xlabel("Predicted yield difference (quintal/acre)")
        axes[0].set_ylabel("Bootstrap response model")
        axes[0].set_yticks(y_positions[::2], [str(v) for v in y_positions[::2]])
        fig.suptitle("Decision-effect direction is not stable across response models", fontsize=12)
        for ext in ("pdf", "png"):
            fig.savefig(figure_dir / f"q2_effect_stability.{ext}", dpi=320 if ext == "png" else None)
        plt.close(fig)


def run_q2(
    model: FittedRegressor,
    train: pd.DataFrame,
    train_validation: pd.DataFrame,
    output_dir: str | Path,
    figure_dir: str | Path,
    bootstrap_models: list[FittedRegressor] | None = None,
) -> dict:
    output_dir = Path(output_dir)
    figure_dir = Path(figure_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)

    medoid_index, medoid_diagnostics = gower_medoid(train)
    representative = train.loc[medoid_index].copy()
    medoid_diagnostics.head(50).to_csv(
        output_dir / "representative_plot_candidates.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(
        {"field": representative.index, "value": representative.astype(str).to_numpy()}
    ).to_csv(output_dir / "representative_plot_record.csv", index=False, encoding="utf-8-sig")

    support = training_support(train)
    baseline_grid = evaluate_grid(model, representative, support[WATER], support[FERTILIZER], 101, 101)
    dense_grid = evaluate_grid(model, representative, support[WATER], support[FERTILIZER], 301, 301)
    baseline_opt = choose_budget_optimum(
        baseline_grid, BASE_WATER_PRICE, BASE_FERTILIZER_PRICE, BASE_BUDGET
    )
    dense_opt = choose_budget_optimum(
        dense_grid, BASE_WATER_PRICE, BASE_FERTILIZER_PRICE, BASE_BUDGET
    )
    local = local_refinement(
        model,
        representative,
        dense_opt,
        support[WATER],
        support[FERTILIZER],
        BASE_WATER_PRICE,
        BASE_FERTILIZER_PRICE,
        BASE_BUDGET,
    )
    main = pd.Series(
        {
            WATER: local["water"],
            FERTILIZER: local["fertilizer"],
            "predicted_yield": local["predicted_yield"],
            "cost_rmb_per_ha": local["cost"],
        }
    )

    if bootstrap_models is None:
        bootstrap_models = fit_bootstrap_models(train_validation, model.features, n_models=20)
    robust_opt, robust_grid = robust_optimum(
        bootstrap_models,
        representative,
        support[WATER],
        support[FERTILIZER],
        BASE_WATER_PRICE,
        BASE_FERTILIZER_PRICE,
        BASE_BUDGET,
    )
    effect_stability = decision_effect_stability(
        bootstrap_models, representative, support[WATER], support[FERTILIZER]
    )
    effect_stability.to_csv(
        output_dir / "q2_decision_effect_stability.csv", index=False, encoding="utf-8-sig"
    )
    robust_selected_frame = candidate_frame(
        representative,
        model,
        np.array([robust_opt[WATER]]),
        np.array([robust_opt[FERTILIZER]]),
    )
    robust_selected_prediction = float(model.predict(robust_selected_frame)[0])

    comparison = pd.DataFrame(
        [
            {"method": "101x101 feasible grid", **baseline_opt.to_dict()},
            {"method": "301x301 grid + local derivative-free refinement", **main.to_dict()},
            {"method": "20-model bootstrap q10 robust optimum", **robust_opt.to_dict()},
        ]
    )
    comparison.to_csv(output_dir / "q2_optimum_comparison.csv", index=False, encoding="utf-8-sig")

    # Reuse model predictions on a 151×151 grid for all price/budget combinations.
    sensitivity_grid = evaluate_grid(model, representative, support[WATER], support[FERTILIZER], 151, 151)
    sensitivity_rows = []
    for water_price in (0.04, 0.20, 0.60):
        for fertilizer_price in (2.19, 3.00, 4.63):
            for budget in (2000.0, 2500.0, 3000.0):
                opt = choose_budget_optimum(sensitivity_grid, water_price, fertilizer_price, budget)
                sensitivity_rows.append(
                    {
                        "water_price_rmb_m3": water_price,
                        "fertilizer_price_rmb_kg": fertilizer_price,
                        "budget_rmb_ha": budget,
                        **opt.to_dict(),
                    }
                )
    pd.DataFrame(sensitivity_rows).to_csv(
        output_dir / "q2_price_budget_sensitivity.csv", index=False, encoding="utf-8-sig"
    )

    # Independent audit from the saved decision vector.
    audit_frame = candidate_frame(
        representative,
        model,
        np.array([main[WATER]]),
        np.array([main[FERTILIZER]]),
    )
    audit_prediction = float(model.predict(audit_frame)[0])
    audit_cost = float(
        economic_cost_per_hectare(
            main[WATER], main[FERTILIZER], BASE_WATER_PRICE, BASE_FERTILIZER_PRICE
        )
    )
    audit = {
        "representative_source_index": medoid_index,
        "water_support_q05_q95": support[WATER],
        "fertilizer_support_q05_q95": support[FERTILIZER],
        "water_unit_interpretation": "source numeric value interpreted as m^3/acre (= thousand L/acre)",
        "fertilizer_unit_interpretation": "kg/acre",
        "water_price_rmb_m3": BASE_WATER_PRICE,
        "fertilizer_price_rmb_kg": BASE_FERTILIZER_PRICE,
        "budget_rmb_ha": BASE_BUDGET,
        "main_decision": {
            "water_m3_acre": float(main[WATER]),
            "water_m3_ha": float(main[WATER] * 2.471053814671653),
            "fertilizer_kg_acre": float(main[FERTILIZER]),
            "fertilizer_kg_ha": float(main[FERTILIZER] * 2.471053814671653),
            "predicted_yield_quintal_acre": float(main["predicted_yield"]),
            "cost_rmb_ha": float(main["cost_rmb_per_ha"]),
            "budget_slack_rmb_ha": float(BASE_BUDGET - main["cost_rmb_per_ha"]),
        },
        "independent_recalculation": {
            "predicted_yield": audit_prediction,
            "cost_rmb_ha": audit_cost,
            "prediction_abs_difference": abs(audit_prediction - float(main["predicted_yield"])),
            "cost_abs_difference": abs(audit_cost - float(main["cost_rmb_per_ha"])),
            "feasible_tolerance_rmb": 1e-6,
            "feasible": bool(audit_cost <= BASE_BUDGET + 1e-6),
        },
        "local_search": local,
        "bootstrap_models": len(bootstrap_models),
        "robust_decision": {k: float(v) for k, v in robust_opt.to_dict().items()},
        "robust_decision_selected_model_prediction": robust_selected_prediction,
        "model_prediction_gap_at_robust_decision": float(
            robust_opt["prediction_mean"] - robust_selected_prediction
        ),
        "main_solution_hits_support_boundary": {
            "water_upper": bool(abs(float(main[WATER]) - support[WATER][1]) <= 1e-6),
            "water_lower": bool(abs(float(main[WATER]) - support[WATER][0]) <= 1e-6),
            "fertilizer_upper": bool(abs(float(main[FERTILIZER]) - support[FERTILIZER][1]) <= 1e-6),
            "fertilizer_lower": bool(abs(float(main[FERTILIZER]) - support[FERTILIZER][0]) <= 1e-6),
        },
        "bootstrap_effect_direction": {
            "water_positive_rate": float(
                (effect_stability["water_high_minus_low_yield"] > 0).mean()
            ),
            "water_delta_median": float(
                effect_stability["water_high_minus_low_yield"].median()
            ),
            "fertilizer_positive_rate": float(
                (effect_stability["fertilizer_high_minus_low_yield"] > 0).mean()
            ),
            "fertilizer_delta_median": float(
                effect_stability["fertilizer_high_minus_low_yield"].median()
            ),
        },
    }
    (output_dir / "q2_summary.json").write_text(
        json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    dense_grid.to_csv(output_dir / "q2_dense_response_grid.csv", index=False, encoding="utf-8-sig")
    robust_grid.to_csv(output_dir / "q2_bootstrap_robust_grid.csv", index=False, encoding="utf-8-sig")
    make_q2_figures(
        figure_dir,
        dense_grid,
        baseline_opt,
        main,
        robust_grid,
        robust_opt,
        support,
        effect_stability,
    )
    return {
        "representative": representative,
        "support": support,
        "main_optimum": main,
        "robust_optimum": robust_opt,
        "bootstrap_models": bootstrap_models,
        "summary": audit,
    }
