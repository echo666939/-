"""Single reproducible entry point for Gate 3 computation and validation."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import time

import pandas as pd

from data_pipeline import (
    DECISION_SAFE_FEATURES,
    SEED,
    TARGET,
    YEAR,
    load_raw,
    write_cleaning_log,
)
from q1_models import run_q1
from q2_optimize import run_q2
from q3_robust import run_q3
from q4_pareto import run_q4
from q5_adaptation import run_q5


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def package_versions() -> dict[str, str]:
    names = [
        "numpy",
        "pandas",
        "scipy",
        "scikit-learn",
        "statsmodels",
        "interpret",
        "catboost",
        "shap",
        "pymoo",
        "matplotlib",
        "seaborn",
        "joblib",
    ]
    return {name: importlib.metadata.version(name) for name in names}


def write_stage3_report(path: Path, results: dict) -> None:
    q1, q2, q3, q4, q5 = (results[f"q{i}"]["summary"] for i in range(1, 6))
    q1_val = q1["selected_2023_metrics"]
    q1_test = q1["selected_refit_2018_2023_locked_2024_metrics"]
    q2_main = q2["main_decision"]
    q2_robust = q2["robust_decision"]
    q3_robust = q3["robust_decision"]
    q4_point = q4["compromise"]
    q5_top = q5["top_three"]
    gate = q1["decision_model_quality_gate_passed"]
    downstream_label = "supported with limitations" if gate else "provisional"
    q2_direction = q2["bootstrap_effect_direction"]
    q2_stable = (
        max(q2_direction["water_positive_rate"], 1 - q2_direction["water_positive_rate"]) >= 0.80
        and max(q2_direction["fertilizer_positive_rate"], 1 - q2_direction["fertilizer_positive_rate"]) >= 0.80
    )
    q3_model_rates = q3.get("response_model_variety_selection_rates", {})
    q3_stable = bool(q3_model_rates) and max(q3_model_rates.values()) >= 0.70
    text = f"""# Gate 3：实算结果与完整验证报告

> 随机种子：{SEED}。原始数据保持只读；本报告中的数值均由 `code/run_gate3.py` 生成。

## 1. 结果总览

| 问题 | 主要方法 | 核心结果 | 证据等级 |
|---|---|---|---|
| 问题一 | 均值、Elastic Net、EBM、CatBoost；按年份外推验证 | 选定模型为 {q1['selected_model']}；2023 RMSE={q1_val['RMSE']:.3f}，R²={q1_val['R2']:.3f}；锁定的2024测试 RMSE={q1_test['RMSE']:.3f}，R²={q1_test['R2']:.3f} | {'verified' if gate else 'supported with limitations'} |
| 问题二 | 101×101基线、301×301密网格+局部搜索、20模型Bootstrap鲁棒优化 | 选定模型下的边界候选：水量={q2_main['water_m3_acre']:.3f} m³/acre，肥量={q2_main['fertilizer_kg_acre']:.3f} kg/acre，预测产量={q2_main['predicted_yield_quintal_acre']:.3f} 公担/英亩，成本={q2_main['cost_rmb_ha']:.2f} 元/公顷 | {'supported with limitations' if q2_stable else 'provisional'} |
| 问题三 | PCA+K-medoids真实情景，品种枚举+水量网格max-min | 选定模型下候选品种={q3_robust['Variety']}，水量={q3_robust['Water_Quantity_liters_per_acre']:.3f} m³/acre，最差情景产量={q3_robust['worst_yield']:.3f} | {'supported with limitations' if q3_stable else 'provisional'} |
| 问题四 | 密网格ε约束式Pareto前沿，NSGA-II对照，理想点距离选折中 | 水量={q4_point['Water_Quantity_liters_per_acre']:.3f} m³/acre，肥量={q4_point['Fertilizer_Quantity']:.3f} kg/acre，产量={q4_point['predicted_yield']:.3f}，环境压力={q4_point['environmental_pressure']:.4f} | {downstream_label} |
| 问题五 | 混合效应校正、CRITIC-TOPSIS、500次排名重采样 | 前三名：{'；'.join(f"{x['rank']}.{x['combo']} (Top-3概率{x['top3_probability']:.1%})" for x in q5_top)} | {'supported with limitations' if q5['ranking_uncertain'] else 'verified'} |

## 2. 问题一：模型比较与解释边界

- 主模型仅使用决策前可获得或作为情景输入的变量；株高、茎粗、糖锤度、病虫害等级等没有进入问题二至四的响应模型。
- 训练集为2018—2022年，2023年用于模型选择，2024年在选择规则锁定后作独立时间外测试。
- EBM/CatBoost中表现更好的复杂模型，只有在2023年RMSE相对Elastic Net改善至少5%时才替代基线；实际改善仅 {q1['best_complex_relative_rmse_gain_vs_elastic_2023']:.2%}，因此保留Elastic Net。
- 绝对残差与预测值的Spearman相关为 {q1['abs_residual_vs_prediction_spearman']:.3f}，用于提示异方差风险。
- 特征重要性与效应方向是预测关联，不是因果效应。

## 3. 问题二：预算约束优化

- 水量原字段按“千升/英亩”等值的m³/acre解释；肥量按kg/acre解释。
- 基准价格：水 {q2['water_price_rmb_m3']:.2f} 元/m³，肥 {q2['fertilizer_price_rmb_kg']:.2f} 元/kg；预算 {q2['budget_rmb_ha']:.0f} 元/公顷。
- 主方案预算余量为 {q2_main['budget_slack_rmb_ha']:.2f} 元/公顷；独立复算的目标差={q2['independent_recalculation']['prediction_abs_difference']:.3e}，成本差={q2['independent_recalculation']['cost_abs_difference']:.3e}。
- Bootstrap下置10%分位的鲁棒方案为：水量 {q2_robust['Water_Quantity_liters_per_acre']:.3f}，肥量 {q2_robust['Fertilizer_Quantity']:.3f}，下置预测 {q2_robust['prediction_q10']:.3f}。
- 20个重采样模型中，增加水量使预测上升的比例为 {q2['bootstrap_effect_direction']['water_positive_rate']:.1%}，增加肥量使预测上升的比例为 {q2['bootstrap_effect_direction']['fertilizer_positive_rate']:.1%}；主解是否触及支持域边界：{q2['main_solution_hits_support_boundary']}。边界命中或方向一致率不足时只能报告建议区间。
- 在鲁棒方案处，Bootstrap模型均值与选定Elastic Net的预测相差 {q2['model_prediction_gap_at_robust_decision']:.3f} 公担/英亩，表明模型结构不确定性不可忽略。
- 价格与预算的27种组合详见 `results/q2/q2_price_budget_sensitivity.csv`。

## 4. 问题三：气候情景与稳健决策

- 三个情景由训练期关键气候变量稳健标准化、PCA保留90%方差、PAM K-medoids聚类得到；每个中心都是数据中的真实记录。
- 稳健方案三情景产量：{', '.join(f"S{i}={q3_robust[f'scenario_{i}_yield']:.3f}" for i in (1,2,3))} 公担/英亩。
- 相对期望值最优方案，稳健方案的期望产量代价为 {q3['price_of_robustness_expected_yield']:.3f}，最坏情景改善为 {q3['robust_worst_case_gain']:.3f}。
- 100次情景中心重采样得到稳健水量95%区间 [{q3['robust_water_bootstrap_interval'][0]:.3f}, {q3['robust_water_bootstrap_interval'][1]:.3f}]。
- 在当前响应模型中，max-min与期望值方案完全一致，因此“鲁棒代价为0”是模型结果，不应写成算法必然性质；20个响应模型重采样下的品种选择率为 {q3.get('response_model_variety_selection_rates', {})}。

## 5. 问题四：Pareto权衡

- 环境压力为水、肥训练期5%—95%支持域归一化平方项的等权和；它是无量纲压力代理量，不是假造的排放或货币损失。
- 该问不继续施加问题二的经济预算，只保留观测支持边界，因为目标已改为“产量—环境”双目标；参考经济成本仍单独给出。
- 折中点由两个目标分别归一化后到理想点的最短距离确定；严格支配它的网格点数量为 {q4['independent_recalculation']['number_of_strict_grid_dominators']}。
- NSGA-II与密网格前沿的中位标准化距离为 {q4['nsga2_comparison']['median_normalized_distance']:.4f}，仅作为非凸搜索对照。

## 6. 问题五：组合排名与不确定性

- 调整模型：{q5['adjustment_model']}；用于综合评价且通过冗余检查的指标为：{', '.join(q5['metrics_used_after_redundancy_check'])}。
- 混合模型警告记录：{q5['fit_attempts'][0]['warnings'] or 'none'}。Hessian非正定意味着标准误与固定效应区间需谨慎解释。
- 第一名组合为 {q5['top_combo']}。其适宜条件只描述观测关联，不宣称品种处理的因果效应。
- 排名不确定性标志：{q5['ranking_uncertain']}。若某前三组合的Top-3概率低于70%，论文必须给出并列候选和概率，不能写成确定顺序。

## 7. 仍需在论文中明确的限制

1. 每行只有一个月份标签，并非真正的12个月面板；气候情景代表记录级联合状态。
2. 水量单位采用经确认的合理解释而非附件中未经证实的字面量，所有推荐均需配合价格/单位敏感性表。
3. 数据存在明显日期与土壤组成矛盾，这些字段已排除，不能据此作机制推断。
4. 响应模型来源于观察数据；即便通过外年验证，优化结果仍是模型支持域内的条件性建议，不是随机试验结论。

## 8. 独立验收入口

- `code/verify_gate3.py` 从磁盘重新读取结果，不依赖建模过程中的内存对象。
- 验收覆盖原始文件哈希、时间留出集、约束复算、情景聚合、Pareto非支配性、排名重采样、代码语法以及PNG/PDF图件配对与分辨率。
- 机器可读结果写入 `results/final_verification_checks.csv` 和 `results/final_verification_summary.json`；警告用于保留实质不确定性，不等于数值复现失败。
"""
    path.write_text(text, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("project_root", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    started = time.time()

    data_dir = root / "data" / "derived"
    results_dir = root / "results"
    model_dir = results_dir / "model_objects"
    figure_dir = root / "manuscript" / "figures"
    for directory in [data_dir, results_dir, model_dir, figure_dir]:
        directory.mkdir(parents=True, exist_ok=True)

    raw_hash_before = sha256(args.input_csv)
    df = load_raw(args.input_csv)
    features = [c for c in DECISION_SAFE_FEATURES if c in df.columns]
    derived = df.loc[:, [YEAR, TARGET] + features].copy()
    derived.insert(0, "source_index", df.index)
    derived.to_csv(data_dir / "modeling_frame_unimputed.csv", index=False, encoding="utf-8-sig")
    write_cleaning_log(data_dir / "cleaning_log.csv", df)

    q1 = run_q1(df, results_dir / "q1", model_dir, figure_dir)
    q2 = run_q2(q1["selected_model"], q1["train"], q1["train_validation"], results_dir / "q2", figure_dir)
    q3 = run_q3(
        q1["selected_model"],
        q1["train"],
        q2["representative"],
        q2["support"]["Water_Quantity_liters_per_acre"],
        float(q2["main_optimum"]["Fertilizer_Quantity"]),
        results_dir / "q3",
        figure_dir,
        bootstrap_models=q2["bootstrap_models"],
    )
    q4 = run_q4(
        q1["selected_model"],
        q2["representative"],
        q2["support"]["Water_Quantity_liters_per_acre"],
        q2["support"]["Fertilizer_Quantity"],
        q2["bootstrap_models"],
        results_dir / "q4",
        figure_dir,
    )
    q5 = run_q5(
        df,
        q1["selected_model"],
        q2["bootstrap_models"],
        q2["representative"],
        q3["scenarios"],
        float(q3["robust"]["Water_Quantity_liters_per_acre"]),
        float(q2["main_optimum"]["Fertilizer_Quantity"]),
        results_dir / "q5",
        figure_dir,
    )

    raw_hash_after = sha256(args.input_csv)
    if raw_hash_before != raw_hash_after:
        raise RuntimeError("Raw input hash changed during Gate 3")

    summaries = {"q1": q1, "q2": q2, "q3": q3, "q4": q4, "q5": q5}
    write_stage3_report(root / "stage3_results_validation.md", summaries)

    q1_gate = q1["summary"]["decision_model_quality_gate_passed"]
    q2_direction = q2["summary"]["bootstrap_effect_direction"]
    q2_recommendation_stable = (
        max(q2_direction["water_positive_rate"], 1 - q2_direction["water_positive_rate"]) >= 0.80
        and max(q2_direction["fertilizer_positive_rate"], 1 - q2_direction["fertilizer_positive_rate"]) >= 0.80
    )
    q3_rates = q3["summary"].get("response_model_variety_selection_rates", {})
    q3_recommendation_stable = bool(q3_rates) and max(q3_rates.values()) >= 0.70
    claim_rows = [
        {
            "claim": "Decision-safe yield response generalizes to future years",
            "status": "verified" if q1_gate else "supported with limitations",
            "evidence": "q1/holdout_metrics.csv and q1/selected_model_metric_intervals.csv",
            "limitation": "observational data and synthetic-looking ranges",
        },
        {
            "claim": "Question 2 single-point agronomic recommendation is stable",
            "status": "supported with limitations" if q1_gate and q2_recommendation_stable else "provisional",
            "evidence": "q2/q2_summary.json and q2/q2_price_budget_sensitivity.csv",
            "limitation": "depends on confirmed unit and price assumptions",
        },
        {
            "claim": "Question 3 robust variety-water recommendation is stable across response models",
            "status": "supported with limitations" if q1_gate and q3_recommendation_stable else "provisional",
            "evidence": "q3/q3_decision_comparison.csv and q3/q3_scenario_bootstrap_stability.csv",
            "limitation": "zero robustness price is data/model specific; three scenarios summarize record-level rather than monthly-panel climate",
        },
        {
            "claim": "Question 4 balance lies on the approximate Pareto frontier",
            "status": "verified" if q4["summary"]["independent_recalculation"]["number_of_strict_grid_dominators"] == 0 else "rejected",
            "evidence": "q4/q4_pareto_frontier.csv and q4/q4_summary.json",
            "limitation": "environment metric is normalized pressure, not measured emissions",
        },
        {
            "claim": "Question 5 Top-3 ordering is stable",
            "status": "supported with limitations" if q5["summary"]["ranking_uncertain"] else "verified",
            "evidence": "q5/q5_final_ranking.csv and q5/q5_bootstrap_ranks.csv",
            "limitation": "associational covariate adjustment; ranking probability must be shown",
        },
    ]
    pd.DataFrame(claim_rows).to_csv(results_dir / "claim_validation_status.csv", index=False, encoding="utf-8-sig")

    traceability = pd.DataFrame(
        [
            ["Q1 factors and model accuracy", "manuscript/figures/q1_*", "results/q1/*", "code/q1_models.py"],
            ["Q2 water/fertilizer recommendation", "manuscript/figures/q2_*", "results/q2/*", "code/q2_optimize.py"],
            ["Q3 robust variety/water decision", "manuscript/figures/q3_*", "results/q3/*", "code/q3_robust.py"],
            ["Q4 Pareto balance", "manuscript/figures/q4_*", "results/q4/*", "code/q4_pareto.py"],
            ["Q5 Top-3 adaptation ranking", "manuscript/figures/q5_*", "results/q5/*", "code/q5_adaptation.py"],
        ],
        columns=["claim", "figure", "result", "code_entry"],
    )
    traceability["derived_data"] = "data/derived/modeling_frame_unimputed.csv"
    traceability["raw_input_sha256"] = raw_hash_before
    traceability.to_csv(results_dir / "traceability_manifest.csv", index=False, encoding="utf-8-sig")

    manifest = {
        "random_seed": SEED,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "package_versions": package_versions(),
        "raw_input": str(args.input_csv),
        "raw_sha256_before": raw_hash_before,
        "raw_sha256_after": raw_hash_after,
        "raw_immutable_check_passed": raw_hash_before == raw_hash_after,
        "started_unix": started,
        "finished_unix": time.time(),
        "runtime_seconds": time.time() - started,
        "primary_year_split": {"train": "2018-2022", "validation": "2023", "locked_test": "2024"},
        "outputs": {
            "human_report": "stage3_results_validation.md",
            "claim_status": "results/claim_validation_status.csv",
            "traceability": "results/traceability_manifest.csv",
        },
    }
    (results_dir / "run_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({"status": "Gate 3 complete", "runtime_seconds": manifest["runtime_seconds"], "q1": q1["summary"], "q2": q2["summary"], "q3": q3["summary"], "q4": q4["summary"], "q5": q5["summary"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
