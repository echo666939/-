"""Question 5: covariate-adjusted variety-season adaptation ranking."""

from __future__ import annotations

from pathlib import Path
import json
import warnings

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from patsy import build_design_matrices

from data_pipeline import CLIMATE_FEATURES, SEED, TARGET, WATER
from q1_models import FittedRegressor
from q3_robust import scenario_candidate_frame


MIXED_COVARIATES = [
    "Temp_Avg_C",
    "Rainfall_Seasonal_mm",
    "Humidity_%",
    "Solar_Radiation_MJ_m2_day",
    "Evapotranspiration_mm_day",
    "Heat_Stress_Days",
    "Frost_Days",
    "Soil_pH",
    "Organic_Carbon_%",
    "Soil_Moisture_%",
    "Water_Holding_Capacity_%",
    "Nitrogen_kg_per_acre",
    "Phosphorus_kg_per_acre",
    "Potassium_kg_per_acre",
    "Groundwater_Level_meters",
    "Water_Quantity_liters_per_acre",
    "Fertilizer_Quantity",
    "Altitude_m",
]


def baseline_combo_statistics(df: pd.DataFrame, n_boot: int = 1000) -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    rows = []
    work = df.dropna(subset=["Variety", "Season", TARGET]).copy()
    for (variety, season), part in work.groupby(["Variety", "Season"]):
        y = part[TARGET].to_numpy(dtype=float)
        boot_mean = np.array([np.mean(rng.choice(y, size=len(y), replace=True)) for _ in range(n_boot)])
        rows.append(
            {
                "Variety": str(variety),
                "Season": str(season),
                "combo": f"{variety} | {season}",
                "n": len(y),
                "mean": float(np.mean(y)),
                "median": float(np.median(y)),
                "std": float(np.std(y, ddof=1)),
                "q10": float(np.quantile(y, 0.10)),
                "mean_ci_2.5": float(np.quantile(boot_mean, 0.025)),
                "mean_ci_97.5": float(np.quantile(boot_mean, 0.975)),
            }
        )
    return pd.DataFrame(rows).sort_values("mean", ascending=False)


def prepare_mixed_data(df: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, tuple[float, float]]]:
    work = df.dropna(subset=["Variety", "Season", TARGET]).copy()
    work["combo"] = work["Variety"].astype(str) + " | " + work["Season"].astype(str)
    work["year_group"] = work["Year"].astype("Int64").astype("string").fillna("Unknown").astype(str)
    work["cluster_group"] = work["Agro_Cluster"].astype("string").fillna("Unknown").astype(str)
    scaling: dict[str, tuple[float, float]] = {}
    for i, column in enumerate(MIXED_COVARIATES):
        s = pd.to_numeric(work[column], errors="coerce")
        median = float(s.median())
        std = float(s.std(ddof=0))
        if not np.isfinite(std) or std < 1e-12:
            std = 1.0
        work[f"z{i}"] = (s.fillna(median) - median) / std
        scaling[column] = (median, std)
    return work, scaling


def fit_adjustment_model(work: pd.DataFrame):
    z_terms = " + ".join(f"z{i}" for i in range(len(MIXED_COVARIATES)))
    formula = f"{TARGET} ~ C(combo) + {z_terms}"
    attempts = []
    for method in ("lbfgs", "powell"):
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                model = smf.mixedlm(
                    formula,
                    data=work,
                    groups=work["year_group"],
                    re_formula="1",
                    vc_formula={"cluster": "0 + C(cluster_group)"},
                )
                result = model.fit(reml=False, method=method, maxiter=1200, disp=False)
            attempts.append(
                {
                    "model": "MixedLM",
                    "method": method,
                    "converged": bool(getattr(result, "converged", False)),
                    "warnings": " | ".join(str(x.message) for x in caught),
                }
            )
            if bool(getattr(result, "converged", False)):
                return result, "MixedLM", attempts
        except Exception as exc:
            attempts.append(
                {"model": "MixedLM", "method": method, "converged": False, "warnings": repr(exc)}
            )

    # Transparent failure path: fixed year and cluster effects retain adjustment
    # but no longer estimate partial pooling.  The fallback is explicitly logged.
    formula_fallback = formula + " + C(year_group) + C(cluster_group)"
    result = smf.ols(formula_fallback, data=work).fit(cov_type="HC3")
    attempts.append(
        {"model": "OLS fixed-effect fallback", "method": "HC3", "converged": True, "warnings": ""}
    )
    return result, "OLS fixed-effect fallback", attempts


def adjusted_combo_means(result, model_type: str, work: pd.DataFrame) -> pd.DataFrame:
    combos = sorted(work["combo"].unique())
    rows = []
    design_info = result.model.data.design_info
    fe_names = list(result.fe_params.index) if model_type == "MixedLM" else list(result.params.index)
    cov = result.cov_params().loc[fe_names, fe_names].to_numpy()
    reference_year = sorted(work["year_group"].unique())[0]
    reference_cluster = sorted(work["cluster_group"].unique())[0]
    for combo in combos:
        row = {"combo": combo, "year_group": reference_year, "cluster_group": reference_cluster}
        row.update({f"z{i}": 0.0 for i in range(len(MIXED_COVARIATES))})
        new = pd.DataFrame([row])
        design = np.asarray(build_design_matrices([design_info], new)[0])[0]
        # For OLS fallback the design includes reference-group fixed effects set to zero.
        vector = design[: len(fe_names)]
        params = result.fe_params.to_numpy() if model_type == "MixedLM" else result.params.to_numpy()
        estimate = float(np.dot(vector, params))
        se = float(np.sqrt(max(np.dot(vector, cov @ vector), 0.0)))
        variety, season = combo.split(" | ", 1)
        rows.append(
            {
                "Variety": variety,
                "Season": season,
                "combo": combo,
                "adjusted_mean": estimate,
                "adjusted_se": se,
                "adjusted_ci_2.5": estimate - 1.96 * se,
                "adjusted_ci_97.5": estimate + 1.96 * se,
            }
        )
    return pd.DataFrame(rows)


def covariate_adjusted_observations(result, model_type: str, work: pd.DataFrame) -> pd.Series:
    params = result.fe_params if model_type == "MixedLM" else result.params
    contribution = np.zeros(len(work))
    for i in range(len(MIXED_COVARIATES)):
        contribution += float(params.get(f"z{i}", 0.0)) * work[f"z{i}"].to_numpy()
    return work[TARGET] - contribution


def scenario_relative_performance(
    model: FittedRegressor,
    representative: pd.Series,
    scenarios: pd.DataFrame,
    combos: pd.DataFrame,
    water: float,
    fertilizer: float,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    for _, combo in combos.iterrows():
        for _, scenario in scenarios.iterrows():
            frame = scenario_candidate_frame(
                representative,
                model,
                scenario,
                str(combo["Variety"]),
                np.array([water]),
                fertilizer,
            )
            frame["Season"] = str(combo["Season"])
            rows.append(
                {
                    "combo": combo["combo"],
                    "scenario_id": int(scenario["scenario_id"]),
                    "predicted_yield": float(model.predict(frame)[0]),
                }
            )
    detailed = pd.DataFrame(rows)
    detailed["relative_to_scenario_best"] = detailed.groupby("scenario_id")["predicted_yield"].transform(
        lambda s: s / s.max()
    )
    summary = (
        detailed.groupby("combo")
        .agg(
            worst_scenario_yield=("predicted_yield", "min"),
            worst_scenario_relative=("relative_to_scenario_best", "min"),
        )
        .reset_index()
    )
    return summary, detailed


def select_nonredundant_metrics(metric_table: pd.DataFrame) -> tuple[list[str], pd.DataFrame]:
    candidates = ["adjusted_mean", "adjusted_q10", "stability_score", "worst_scenario_relative"]
    corr = metric_table[candidates].corr(method="spearman")
    priority = ["adjusted_mean", "stability_score", "worst_scenario_relative", "adjusted_q10"]
    selected = []
    for candidate in priority:
        if all(abs(float(corr.loc[candidate, kept])) < 0.95 for kept in selected):
            selected.append(candidate)
    if len(selected) < 2:
        selected = ["adjusted_mean", "stability_score"]
    return selected, corr


def critic_topsis(metric_table: pd.DataFrame, metrics: list[str]) -> tuple[pd.DataFrame, pd.DataFrame]:
    values = metric_table[metrics].astype(float)
    normalized = (values - values.min()) / (values.max() - values.min()).replace(0, 1)
    corr = normalized.corr().fillna(0.0)
    contrast = normalized.std(ddof=0) * (1.0 - corr).sum(axis=1)
    if float(contrast.sum()) <= 1e-12:
        weights = pd.Series(1 / len(metrics), index=metrics)
    else:
        weights = contrast / contrast.sum()
    weighted = normalized * weights
    ideal_best = weighted.max(axis=0)
    ideal_worst = weighted.min(axis=0)
    d_pos = np.sqrt(((weighted - ideal_best) ** 2).sum(axis=1))
    d_neg = np.sqrt(((weighted - ideal_worst) ** 2).sum(axis=1))
    closeness = d_neg / np.clip(d_pos + d_neg, 1e-12, None)
    ranked = metric_table.copy()
    ranked["topsis_score"] = closeness
    ranked["rank"] = ranked["topsis_score"].rank(ascending=False, method="min").astype(int)
    weight_table = pd.DataFrame({"metric": weights.index, "critic_weight": weights.values})
    return ranked.sort_values("rank"), weight_table


def bootstrap_rank_stability(
    work: pd.DataFrame,
    adjusted: pd.DataFrame,
    scenario_by_model: list[pd.DataFrame],
    metrics_used: list[str],
    n_boot: int = 500,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(SEED)
    combos = adjusted["combo"].tolist()
    base_se = adjusted.set_index("combo")["adjusted_se"]
    base_mean = adjusted.set_index("combo")["adjusted_mean"]
    draws = []
    for b in range(n_boot):
        scenario_table = scenario_by_model[int(rng.integers(0, len(scenario_by_model)))].set_index("combo")
        rows = []
        for combo in combos:
            part = work[work["combo"] == combo]
            sample = part.iloc[rng.integers(0, len(part), len(part))]
            group_means = sample.groupby(["year_group", "cluster_group"])["adjusted_observation"].mean()
            adjusted_mean_draw = float(rng.normal(base_mean[combo], max(base_se[combo], 1e-8)))
            rows.append(
                {
                    "combo": combo,
                    "adjusted_mean": adjusted_mean_draw,
                    "adjusted_q10": float(sample["adjusted_observation"].quantile(0.10)),
                    "stability_score": -float(group_means.std(ddof=0)),
                    "worst_scenario_relative": float(scenario_table.loc[combo, "worst_scenario_relative"]),
                }
            )
        ranked, _ = critic_topsis(pd.DataFrame(rows), metrics_used)
        for _, row in ranked.iterrows():
            draws.append({"bootstrap": b, "combo": row["combo"], "rank": int(row["rank"])})
    detailed = pd.DataFrame(draws)
    summary = (
        detailed.groupby("combo")["rank"]
        .agg(
            median_rank="median",
            rank_ci_2_5=lambda s: s.quantile(0.025),
            rank_ci_97_5=lambda s: s.quantile(0.975),
            rank1_probability=lambda s: np.mean(s == 1),
            top3_probability=lambda s: np.mean(s <= 3),
        )
        .rename(columns={"rank_ci_2_5": "rank_ci_2.5", "rank_ci_97_5": "rank_ci_97.5"})
        .reset_index()
    )
    return summary, detailed


def top_combo_conditions(df: pd.DataFrame, combo: str) -> pd.DataFrame:
    variety, season = combo.split(" | ", 1)
    subset = df[(df["Variety"].astype(str) == variety) & (df["Season"].astype(str) == season)]
    variables = [
        "Temp_Avg_C",
        "Rainfall_Seasonal_mm",
        "Humidity_%",
        "Solar_Radiation_MJ_m2_day",
        "Soil_pH",
        "Organic_Carbon_%",
        "Soil_Moisture_%",
        "Water_Holding_Capacity_%",
        "Nitrogen_kg_per_acre",
        "Phosphorus_kg_per_acre",
        "Potassium_kg_per_acre",
    ]
    rows = []
    for variable in variables:
        rows.append(
            {
                "variable": variable,
                "top_combo_mean": float(subset[variable].mean()),
                "top_combo_q25": float(subset[variable].quantile(0.25)),
                "top_combo_q75": float(subset[variable].quantile(0.75)),
                "overall_mean": float(df[variable].mean()),
                "overall_std": float(df[variable].std(ddof=0)),
                "standardized_difference": float(
                    (subset[variable].mean() - df[variable].mean()) / max(df[variable].std(ddof=0), 1e-12)
                ),
            }
        )
    return pd.DataFrame(rows)


def make_q5_figures(
    figure_dir: Path,
    adjusted: pd.DataFrame,
    ranking: pd.DataFrame,
    conditions: pd.DataFrame,
) -> None:
    figure_dir.mkdir(parents=True, exist_ok=True)
    plt.style.use("seaborn-v0_8-whitegrid")

    plot = adjusted.sort_values("adjusted_mean")
    fig, ax = plt.subplots(figsize=(8.1, 4.8), constrained_layout=True)
    ax.errorbar(
        plot["adjusted_mean"],
        plot["combo"],
        xerr=1.96 * plot["adjusted_se"],
        fmt="o",
        color="#4C78A8",
        ecolor="#777777",
        capsize=3,
    )
    ax.set_xlabel("Covariate-adjusted yield (quintal/acre)")
    ax.set_title("Variety–season adjusted performance")
    for ext in ("pdf", "png"):
        fig.savefig(figure_dir / f"q5_adjusted_means.{ext}", dpi=320 if ext == "png" else None)
    plt.close(fig)

    plot = ranking.sort_values("topsis_score")
    fig, ax = plt.subplots(figsize=(8.1, 4.8), constrained_layout=True)
    bars = ax.barh(plot["combo"], plot["topsis_score"], color="#59A14F")
    for bar, probability in zip(bars, plot["top3_probability"]):
        ax.text(bar.get_width() + 0.01, bar.get_y() + bar.get_height() / 2, f"Top-3 {probability:.0%}", va="center", fontsize=8)
    ax.set_xlim(0, 1.12)
    ax.set_xlabel("CRITIC–TOPSIS score")
    ax.set_title("Composite ranking and bootstrap stability")
    for ext in ("pdf", "png"):
        fig.savefig(figure_dir / f"q5_composite_ranking.{ext}", dpi=320 if ext == "png" else None)
    plt.close(fig)

    plot = conditions.sort_values("standardized_difference")
    colors = ["#D55E00" if x < 0 else "#4C78A8" for x in plot["standardized_difference"]]
    fig, ax = plt.subplots(figsize=(8.2, 5.1), constrained_layout=True)
    ax.barh(plot["variable"], plot["standardized_difference"], color=colors)
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_xlabel("Difference from overall mean (standard deviations)")
    ax.set_title("Observed climate and soil profile of the top combination")
    for ext in ("pdf", "png"):
        fig.savefig(figure_dir / f"q5_top_combo_conditions.{ext}", dpi=320 if ext == "png" else None)
    plt.close(fig)


def run_q5(
    df: pd.DataFrame,
    model: FittedRegressor,
    bootstrap_models: list[FittedRegressor],
    representative: pd.Series,
    scenarios: pd.DataFrame,
    robust_water: float,
    fertilizer: float,
    output_dir: str | Path,
    figure_dir: str | Path,
) -> dict:
    output_dir = Path(output_dir)
    figure_dir = Path(figure_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)

    baseline = baseline_combo_statistics(df)
    baseline.to_csv(output_dir / "q5_baseline_combo_statistics.csv", index=False, encoding="utf-8-sig")
    work, scaling = prepare_mixed_data(df)
    result, model_type, attempts = fit_adjustment_model(work)
    adjusted = adjusted_combo_means(result, model_type, work)
    adjusted["n"] = adjusted["combo"].map(work["combo"].value_counts())
    adjusted.to_csv(output_dir / "q5_adjusted_combo_means.csv", index=False, encoding="utf-8-sig")

    work["adjusted_observation"] = covariate_adjusted_observations(result, model_type, work)
    distribution = (
        work.groupby("combo")
        .agg(
            adjusted_q10=("adjusted_observation", lambda s: s.quantile(0.10)),
            group_stability_sd=("adjusted_observation", "std"),
        )
        .reset_index()
    )
    stability_rows = []
    for combo, part in work.groupby("combo"):
        group_means = part.groupby(["year_group", "cluster_group"])["adjusted_observation"].mean()
        stability_rows.append({"combo": combo, "stability_score": -float(group_means.std(ddof=0))})
    stability = pd.DataFrame(stability_rows)

    scenario_summary, scenario_detail = scenario_relative_performance(
        model,
        representative,
        scenarios,
        adjusted[["Variety", "Season", "combo"]],
        robust_water,
        fertilizer,
    )
    scenario_detail.to_csv(output_dir / "q5_combo_scenario_predictions.csv", index=False, encoding="utf-8-sig")

    metric_table = adjusted.merge(distribution, on="combo").merge(stability, on="combo").merge(scenario_summary, on="combo")
    metrics_used, corr = select_nonredundant_metrics(metric_table)
    corr.to_csv(output_dir / "q5_metric_correlations.csv", encoding="utf-8-sig")
    ranked, weights = critic_topsis(metric_table, metrics_used)
    weights.to_csv(output_dir / "q5_critic_weights.csv", index=False, encoding="utf-8-sig")

    scenario_by_model = []
    for boot_model in bootstrap_models:
        boot_summary, _ = scenario_relative_performance(
            boot_model,
            representative,
            scenarios,
            adjusted[["Variety", "Season", "combo"]],
            robust_water,
            fertilizer,
        )
        scenario_by_model.append(boot_summary)
    stability_summary, stability_detail = bootstrap_rank_stability(
        work, adjusted, scenario_by_model, metrics_used, n_boot=500
    )
    ranking = ranked.merge(stability_summary, on="combo")
    ranking.to_csv(output_dir / "q5_final_ranking.csv", index=False, encoding="utf-8-sig")
    stability_detail.to_csv(output_dir / "q5_bootstrap_ranks.csv", index=False, encoding="utf-8-sig")

    top_combo = str(ranking.sort_values("rank").iloc[0]["combo"])
    conditions = top_combo_conditions(df, top_combo)
    conditions.to_csv(output_dir / "q5_top_combo_conditions.csv", index=False, encoding="utf-8-sig")

    # Equal-weight sensitivity on the same retained metric set.
    values = metric_table[metrics_used]
    normalized = (values - values.min()) / (values.max() - values.min()).replace(0, 1)
    metric_table["equal_weight_score"] = normalized.mean(axis=1)
    metric_table["equal_weight_rank"] = metric_table["equal_weight_score"].rank(ascending=False, method="min")
    metric_table[["combo", "equal_weight_score", "equal_weight_rank"]].to_csv(
        output_dir / "q5_equal_weight_sensitivity.csv", index=False, encoding="utf-8-sig"
    )

    top_three = ranking.sort_values("rank").head(3)
    summary = {
        "random_seed": SEED,
        "adjustment_model": model_type,
        "fit_attempts": attempts,
        "model_converged": bool(getattr(result, "converged", True)),
        "n_model_rows": len(work),
        "combination_count": len(adjusted),
        "mixed_covariates": MIXED_COVARIATES,
        "metrics_considered": ["adjusted_mean", "adjusted_q10", "stability_score", "worst_scenario_relative"],
        "metrics_used_after_redundancy_check": metrics_used,
        "critic_weights": weights.set_index("metric")["critic_weight"].to_dict(),
        "top_three": [
            {
                "rank": int(row["rank"]),
                "combo": str(row["combo"]),
                "topsis_score": float(row["topsis_score"]),
                "top3_probability": float(row["top3_probability"]),
                "rank1_probability": float(row["rank1_probability"]),
            }
            for _, row in top_three.iterrows()
        ],
        "ranking_uncertain": bool((top_three["top3_probability"] < 0.70).any()),
        "top_combo": top_combo,
        "interpretation_warning": "Adjusted and predictive comparisons are associative, not causal variety-treatment effects.",
        "covariate_scaling": {k: [float(v[0]), float(v[1])] for k, v in scaling.items()},
    }
    (output_dir / "q5_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    make_q5_figures(figure_dir, adjusted, ranking, conditions)
    return {
        "baseline": baseline,
        "adjusted": adjusted,
        "ranking": ranking,
        "conditions": conditions,
        "summary": summary,
    }
