"""Apply the audited simplicity rule without repeating completed candidate CV."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from data_pipeline import DECISION_SAFE_FEATURES, TARGET, YEAR, load_raw
from q1_models import (
    bootstrap_metric_intervals,
    fit_elastic,
    fit_mean,
    group_error_table,
    make_q1_figures,
    marginal_effects,
    permutation_importance_raw,
    regression_metrics,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("project_root", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    q1_dir = root / "results" / "q1"
    model_dir = root / "results" / "model_objects"
    figure_dir = root / "manuscript" / "figures"
    df = load_raw(args.input_csv)
    known = df[df[YEAR].notna()].copy()
    train = known[known[YEAR].between(2018, 2022, inclusive="both")].copy()
    validation = known[known[YEAR].eq(2023)].copy()
    test = known[known[YEAR].eq(2024)].copy()
    train_validation = known[known[YEAR].between(2018, 2023, inclusive="both")].copy()
    features = [c for c in DECISION_SAFE_FEATURES if c in df.columns]

    old = json.loads((q1_dir / "q1_summary.json").read_text(encoding="utf-8"))
    alpha = float(old["elastic_alpha"])
    l1_ratio = float(old["elastic_l1_ratio"])
    elastic_train = fit_elastic(train, features, alpha, l1_ratio)
    elastic_deployment = fit_elastic(train_validation, features, alpha, l1_ratio)
    ebm = joblib.load(model_dir / "ebm_train_2018_2022.joblib")
    catboost = joblib.load(model_dir / "catboost_train_2018_2022.joblib")
    mean = fit_mean(train, features)

    joblib.dump(elastic_train, model_dir / "selected_model_train_2018_2022.joblib")
    joblib.dump(elastic_deployment, model_dir / "selected_model_train_2018_2023.joblib")

    selected_val_pred = elastic_train.predict(validation)
    selected_test_pred = elastic_deployment.predict(test)
    pd.DataFrame(
        {
            "source_index": validation.index,
            "year": validation[YEAR].to_numpy(),
            "observed": validation[TARGET].to_numpy(),
            "predicted": selected_val_pred,
            "residual": validation[TARGET].to_numpy() - selected_val_pred,
        }
    ).to_csv(q1_dir / "selected_model_2023_predictions.csv", index=False, encoding="utf-8-sig")
    bootstrap_metric_intervals(validation[TARGET].to_numpy(), selected_val_pred).to_csv(
        q1_dir / "selected_model_metric_intervals.csv", index=False, encoding="utf-8-sig"
    )
    group_error_table(validation, selected_val_pred).to_csv(
        q1_dir / "selected_model_subgroup_errors.csv", index=False, encoding="utf-8-sig"
    )
    importance = permutation_importance_raw(elastic_train, validation)
    importance.to_csv(q1_dir / "selected_model_permutation_importance.csv", index=False, encoding="utf-8-sig")
    effect_features = importance.head(15)["feature"].tolist()
    for required in ["Water_Quantity_liters_per_acre", "Fertilizer_Quantity"]:
        if required not in effect_features:
            effect_features.append(required)
    effect_summary, effect_curves = marginal_effects(
        elastic_train, train, validation, effect_features
    )
    effect_summary.to_csv(q1_dir / "selected_model_effect_directions.csv", index=False, encoding="utf-8-sig")
    effect_curves.to_csv(q1_dir / "selected_model_effect_curves.csv", index=False, encoding="utf-8-sig")

    metrics = pd.read_csv(q1_dir / "holdout_metrics.csv")
    predictions = {
        "Mean baseline": mean.predict(validation),
        "Elastic Net": selected_val_pred,
        "EBM": ebm.predict(validation),
        "CatBoost": catboost.predict(validation),
    }
    make_q1_figures(
        figure_dir,
        metrics,
        validation,
        predictions,
        importance,
        effect_curves,
        "Elastic Net",
    )

    val_metrics = metrics[metrics["split"] == "2023_validation"].set_index("model")
    elastic_rmse = float(val_metrics.loc["Elastic Net", "RMSE"])
    ebm_rmse = float(val_metrics.loc["EBM", "RMSE"])
    cat_rmse = float(val_metrics.loc["CatBoost", "RMSE"])
    best_complex_rmse = min(ebm_rmse, cat_rmse)
    residual = validation[TARGET].to_numpy() - selected_val_pred
    summary = {
        **old,
        "selected_model": "Elastic Net",
        "catboost_relative_rmse_gain_vs_ebm_2023": (ebm_rmse - cat_rmse) / ebm_rmse,
        "best_complex_relative_rmse_gain_vs_elastic_2023": (elastic_rmse - best_complex_rmse) / elastic_rmse,
        "selected_2023_metrics": regression_metrics(validation[TARGET], selected_val_pred),
        "selected_refit_2018_2023_locked_2024_metrics": regression_metrics(test[TARGET], selected_test_pred),
        "abs_residual_vs_prediction_spearman": float(
            pd.Series(np.abs(residual)).corr(pd.Series(selected_val_pred), method="spearman")
        ),
        "decision_model_quality_gate_passed": bool(
            regression_metrics(validation[TARGET], selected_val_pred)["R2"] >= 0.30
        ),
        "selection_rule": "Select the best of EBM/CatBoost only if it improves 2023 RMSE by at least 5% over Elastic Net; otherwise retain Elastic Net",
        "selection_audit_note": "CatBoost improved only marginally over Elastic Net; EBM was slightly worse. Complexity was rejected.",
    }
    (q1_dir / "q1_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
