"""Shared, leakage-safe data preparation for the sugarcane B problem.

The raw CSV is read-only.  This module deliberately separates predictors that
are available before a management decision from variables observed during or
near the end of the crop cycle.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


SEED = 20260728
TARGET = "Yield_Quintal_per_Acre"
YEAR = "Year"
WATER = "Water_Quantity_liters_per_acre"
FERTILIZER = "Fertilizer_Quantity"

CLIMATE_FEATURES = [
    "Month",
    "Temp_Min_C",
    "Temp_Max_C",
    "Temp_Avg_C",
    "Rainfall_Total_mm",
    "Rainfall_Seasonal_mm",
    "Humidity_%",
    "Solar_Radiation_MJ_m2_day",
    "Sunshine_Hours_decimal",
    "Wind_Speed_kmph",
    "Evapotranspiration_mm_day",
    "Dew_Point_C",
    "Heat_Stress_Days",
    "Frost_Days",
]

SOIL_FEATURES = [
    "Soil_Type",
    "Soil_pH",
    "EC",
    "Organic_Carbon_%",
    "Soil_Moisture_%",
    "Soil_Depth_cm",
    "Water_Holding_Capacity_%",
    "Nitrogen_kg_per_acre",
    "Phosphorus_kg_per_acre",
    "Potassium_kg_per_acre",
    "Zinc_mg_per_kg",
    "Iron_mg_per_kg",
    "Copper_mg_per_kg",
    "Manganese_mg_per_kg",
    "Sulfur_kg_per_acre",
]

WATER_FEATURES = [
    "Irrigation_Frequency_Level",
    WATER,
    "Irrigation_Method_Type",
    "Groundwater_Level_meters",
    "Water_Quality_Category",
]

PLANTING_FEATURES = [
    "Crop_Duration_Days",
    "Seed_Rate",
    "Row_Spacing_cm",
    "Row_Gap_cm",
    "Plant_Density",
    "Intercropping",
    "Weed_Control",
    "Soil_Condition_At_Planting",
    "Planting_Method",
    "Mulching",
    "Fertilizer_Split",
    "Drainage_Condition",
]

FERTILIZER_FEATURES = ["Fertilizer_Type", FERTILIZER, "Application_Timing"]

CONTEXT_FEATURES = [
    "Variety",
    "Latitude",
    "Longitude",
    "Altitude_m",
    "Tehsil",
    "Agro_Cluster",
    "Season",
]

# These fields are known only after planting or are strongly outcome-adjacent.
POST_GROWTH_FEATURES = [
    "Germination_%",
    "Tillering_Count",
    "Cane_Height_cm",
    "Cane_Diameter_cm",
    "Internode_Length_cm",
    "Brix_Value",
    "Disease_Type",
    "Disease_Severity",
    "Pest_Level",
    "Growth_Stage",
]

# In-season operations are retained only in the auxiliary full-season model.
IN_SEASON_OPERATION_FEATURES = ["Pesticide_Usage", "Machinery_Use", "Labor_Input"]

DECISION_SAFE_FEATURES = (
    CLIMATE_FEATURES
    + SOIL_FEATURES
    + WATER_FEATURES
    + PLANTING_FEATURES
    + FERTILIZER_FEATURES
    + CONTEXT_FEATURES
)

FULL_SEASON_FEATURES = DECISION_SAFE_FEATURES + POST_GROWTH_FEATURES + IN_SEASON_OPERATION_FEATURES

CLIMATE_SCENARIO_FEATURES = [
    "Temp_Avg_C",
    "Rainfall_Seasonal_mm",
    "Humidity_%",
    "Solar_Radiation_MJ_m2_day",
    "Evapotranspiration_mm_day",
    "Heat_Stress_Days",
    "Frost_Days",
]

# Kept from an actual record when constructing a representative plot.  The two
# controllable resource quantities are intentionally excluded.
REPRESENTATIVE_FEATURES = [
    c
    for c in DECISION_SAFE_FEATURES
    if c not in {WATER, FERTILIZER, "Month"}
]


def parse_sunshine_hours(series: pd.Series) -> pd.Series:
    """Convert HH:MM duration strings to decimal hours without guessing bad rows."""

    text = series.astype("string")
    parts = text.str.extract(r"^\s*(\d{1,2}):(\d{2})\s*$")
    hours = pd.to_numeric(parts[0], errors="coerce")
    minutes = pd.to_numeric(parts[1], errors="coerce")
    valid = hours.between(0, 24) & minutes.between(0, 59)
    result = hours + minutes / 60.0
    return result.where(valid)


def load_raw(path: str | Path) -> pd.DataFrame:
    """Read the immutable source and add only documented derived columns."""

    df = pd.read_csv(path, encoding="utf-8-sig")
    df["Sunshine_Hours_decimal"] = parse_sunshine_hours(df["Sunshine_Hours_hh_mm"])
    df[YEAR] = pd.to_numeric(df[YEAR], errors="coerce")
    return df


def model_frame(df: pd.DataFrame, features: Iterable[str]) -> pd.DataFrame:
    """Return the requested model columns in a stable order."""

    cols = [c for c in features if c in df.columns]
    return df.loc[:, cols].copy()


def split_years(df: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """Primary leakage-safe split confirmed at Gate 1."""

    return {
        "train": df[df[YEAR].between(2018, 2022, inclusive="both")].copy(),
        "validation": df[df[YEAR].eq(2023)].copy(),
        "test": df[df[YEAR].eq(2024)].copy(),
        "unknown_year": df[df[YEAR].isna()].copy(),
    }


def expanding_year_folds(train_df: pd.DataFrame) -> list[tuple[np.ndarray, np.ndarray, int]]:
    """Expanding-window folds: 2018-19->2020, then through 2022."""

    folds: list[tuple[np.ndarray, np.ndarray, int]] = []
    years = train_df[YEAR].to_numpy()
    for validation_year in (2020, 2021, 2022):
        tr = np.flatnonzero((years >= 2018) & (years < validation_year))
        va = np.flatnonzero(years == validation_year)
        if tr.size and va.size:
            folds.append((tr, va, validation_year))
    return folds


def numeric_and_categorical(df: pd.DataFrame, features: Iterable[str]) -> tuple[list[str], list[str]]:
    cols = [c for c in features if c in df.columns]
    numeric = [c for c in cols if pd.api.types.is_numeric_dtype(df[c])]
    categorical = [c for c in cols if c not in numeric]
    return numeric, categorical


@dataclass
class TabularFiller:
    """Training-only imputation used by EBM and CatBoost."""

    numeric: list[str]
    categorical: list[str]
    medians: dict[str, float]

    @classmethod
    def fit(cls, frame: pd.DataFrame, features: Iterable[str]) -> "TabularFiller":
        numeric, categorical = numeric_and_categorical(frame, features)
        medians = {
            c: float(pd.to_numeric(frame[c], errors="coerce").median())
            for c in numeric
        }
        return cls(numeric=numeric, categorical=categorical, medians=medians)

    def transform(self, frame: pd.DataFrame) -> pd.DataFrame:
        out = frame.loc[:, self.numeric + self.categorical].copy()
        for c in self.numeric:
            out[c] = pd.to_numeric(out[c], errors="coerce").fillna(self.medians[c]).astype(float)
        for c in self.categorical:
            out[c] = out[c].astype("string").fillna("__MISSING__").astype(str)
        return out

    @property
    def ordered_features(self) -> list[str]:
        return self.numeric + self.categorical

    @property
    def feature_types(self) -> list[str]:
        return ["continuous"] * len(self.numeric) + ["nominal"] * len(self.categorical)


def training_support(train_df: pd.DataFrame, low: float = 0.05, high: float = 0.95) -> dict[str, tuple[float, float]]:
    return {
        WATER: (float(train_df[WATER].quantile(low)), float(train_df[WATER].quantile(high))),
        FERTILIZER: (
            float(train_df[FERTILIZER].quantile(low)),
            float(train_df[FERTILIZER].quantile(high)),
        ),
    }


def acre_to_hectare_factor() -> float:
    return 2.471053814671653


def economic_cost_per_hectare(
    water_value: np.ndarray | float,
    fertilizer_value: np.ndarray | float,
    water_price_rmb_m3: float,
    fertilizer_price_rmb_kg: float,
) -> np.ndarray:
    """Confirmed interpretation: water value=m^3/acre, fertilizer=kg/acre."""

    factor = acre_to_hectare_factor()
    return factor * (
        water_price_rmb_m3 * np.asarray(water_value, dtype=float)
        + fertilizer_price_rmb_kg * np.asarray(fertilizer_value, dtype=float)
    )


def write_cleaning_log(path: str | Path, df: pd.DataFrame) -> None:
    """Write an auditable cleaning/exclusion ledger."""

    rows = [
        {
            "issue": "Sunshine duration stored as HH:MM text",
            "decision": "create Sunshine_Hours_decimal; invalid patterns become missing",
            "affected": int(df["Sunshine_Hours_decimal"].isna().sum()),
            "rationale": "preserve duration meaning for numeric models",
            "risk": "source field may not represent a full-season total",
        },
        {
            "issue": "Planting/harvesting dates fail chronology and duration checks",
            "decision": "exclude both date fields from all fitted models",
            "affected": int(len(df)),
            "rationale": "avoid learning from internally inconsistent timestamps",
            "risk": "seasonal timing signal may be partly lost",
        },
        {
            "issue": "Sand, silt and clay rarely sum to approximately 100%",
            "decision": "exclude all three texture fractions from the primary models",
            "affected": int(df[["Sand_%", "Silt_%", "Clay_%"]].notna().any(axis=1).sum()),
            "rationale": "composition is not physically coherent",
            "risk": "Soil_Type is a coarser substitute",
        },
        {
            "issue": "Constant administrative fields and identifier-like Khasra_No",
            "decision": "exclude State, District, Sugar_Mill, Region and Khasra_No",
            "affected": int(len(df)),
            "rationale": "no transferable signal; prevent memorization",
            "risk": "none for within-region inference",
        },
        {
            "issue": "Post-growth and outcome-adjacent measurements",
            "decision": "exclude from decision-safe model; retain only in labeled auxiliary model",
            "affected": int(len(df)),
            "rationale": "prevent target leakage in Questions 2-4",
            "risk": "lower but honest advance-prediction accuracy",
        },
        {
            "issue": "Missing values across most rows",
            "decision": "no complete-case deletion; fit median/category imputations on each training fold",
            "affected": int(df.isna().any(axis=1).sum()),
            "rationale": "preserve sample size without validation leakage",
            "risk": "missingness may be informative; indicator checks are retained in Elastic Net",
        },
        {
            "issue": "Year missing or outside confirmed validation periods",
            "decision": "exclude unknown-year rows from primary time validation",
            "affected": int(df[YEAR].isna().sum()),
            "rationale": "maintain an auditable chronological split",
            "risk": "97 observations do not contribute to primary performance claims",
        },
    ]
    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")

