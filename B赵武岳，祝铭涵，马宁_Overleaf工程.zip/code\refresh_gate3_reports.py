"""Regenerate Gate 3 narrative/status files from validated result summaries."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from run_gate3 import write_stage3_report


def load_summary(root: Path, question: int) -> dict:
    path = root / "results" / f"q{question}" / f"q{question}_summary.json"
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_root", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    summaries = {f"q{i}": {"summary": load_summary(root, i)} for i in range(1, 6)}
    write_stage3_report(root / "stage3_results_validation.md", summaries)

    q1, q2, q3, q4, q5 = (summaries[f"q{i}"]["summary"] for i in range(1, 6))
    d = q2["bootstrap_effect_direction"]
    q2_stable = (
        max(d["water_positive_rate"], 1 - d["water_positive_rate"]) >= 0.80
        and max(d["fertilizer_positive_rate"], 1 - d["fertilizer_positive_rate"]) >= 0.80
    )
    rates = q3.get("response_model_variety_selection_rates", {})
    q3_stable = bool(rates) and max(rates.values()) >= 0.70
    rows = [
        [
            "Decision-safe yield response generalizes moderately to future years",
            "verified" if q1["decision_model_quality_gate_passed"] else "supported with limitations",
            "q1/holdout_metrics.csv and q1/selected_model_metric_intervals.csv",
            "R2 is moderate; observational data do not establish causal effects",
        ],
        [
            "Question 2 single-point agronomic recommendation is stable",
            "supported with limitations" if q2_stable else "provisional",
            "q2/q2_summary.json and q2/q2_decision_effect_stability.csv",
            "water/fertilizer directions vary across models and the main solution hits support boundaries",
        ],
        [
            "Question 3 robust variety-water recommendation is stable across response models",
            "supported with limitations" if q3_stable else "provisional",
            "q3/q3_decision_comparison.csv and q3/q3_response_model_stability.csv",
            "zero robustness price holds only for the selected model; response-model choices vary",
        ],
        [
            "Question 4 balance lies on the selected-model approximate Pareto frontier",
            "supported with limitations" if q4["independent_recalculation"]["number_of_strict_grid_dominators"] == 0 else "rejected",
            "q4/q4_pareto_frontier.csv and q4/q4_summary.json",
            "environment metric is normalized pressure and bootstrap decision intervals are wide",
        ],
        [
            "Question 5 Top-3 ordering is stable",
            "supported with limitations" if q5["ranking_uncertain"] else "verified",
            "q5/q5_final_ranking.csv and q5/q5_bootstrap_ranks.csv",
            "all reported Top-3 inclusion probabilities are below 70%; MixedLM Hessian warning applies",
        ],
    ]
    pd.DataFrame(rows, columns=["claim", "status", "evidence", "limitation"]).to_csv(
        root / "results" / "claim_validation_status.csv", index=False, encoding="utf-8-sig"
    )


if __name__ == "__main__":
    main()

