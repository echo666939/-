"""Question 3: real-medoid climate scenarios and max-min planting decisions."""

from __future__ import annotations

from pathlib import Path
import json

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from sklearn.decomposition import PCA
from sklearn.preprocessing import RobustScaler

from data_pipeline import (
    CLIMATE_FEATURES,
    CLIMATE_SCENARIO_FEATURES,
    FERTILIZER,
    SEED,
    WATER,
    YEAR,
)
from q1_models import FittedRegressor
from q2_optimize import candidate_frame


def pam_kmedoids(x: np.ndarray, k: int = 3, n_starts: int = 20) -> tuple[np.ndarray, np.ndarray, float]:
    """Small deterministic multi-start PAM implementation on Euclidean distance."""

    rng = np.random.default_rng(SEED)
    distances = cdist(x, x, metric="euclidean").astype(np.float32)
    best_medoids = None
    best_labels = None
    best_loss = np.inf
    for _ in range(n_starts):
        medoids = rng.choice(len(x), size=k, replace=False)
        for _iteration in range(100):
            labels = np.argmin(distances[:, medoids], axis=1)
            new_medoids = medoids.copy()
            for cluster in range(k):
                members = np.flatnonzero(labels == cluster)
                if len(members) == 0:
                    candidates = np.setdiff1d(np.arange(len(x)), new_medoids)
                    new_medoids[cluster] = rng.choice(candidates)
                    continue
                intra = distances[np.ix_(members, members)].sum(axis=1)
                new_medoids[cluster] = members[int(np.argmin(intra))]
            if np.array_equal(np.sort(new_medoids), np.sort(medoids)):
                medoids = new_medoids
                break
            medoids = new_medoids
        labels = np.argmin(distances[:, medoids], axis=1)
        loss = float(distances[np.arange(len(x)), medoids[labels]].sum())
        if loss < best_loss:
            best_loss = loss
            best_medoids = medoids.copy()
            best_labels = labels.copy()
    if best_medoids is None or best_labels is None:
        raise RuntimeError("K-medoids failed")
    return best_medoids, best_labels, best_loss


def build_scenarios(train: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    features = [c for c in CLIMATE_SCENARIO_FEATURES if c in train.columns]
    x = train[features].copy()
    medians = x.median(numeric_only=True)
    x = x.fillna(medians)
    scaler = RobustScaler().fit(x)
    scaled = scaler.transform(x)
    pca = PCA(n_components=0.90, svd_solver="full", random_state=SEED).fit(scaled)
    z = pca.transform(scaled)
    medoid_positions, labels, loss = pam_kmedoids(z, k=3, n_starts=25)

    rows = []
    for cluster, position in enumerate(medoid_positions):
        source_index = int(train.index[position])
        row = {
            "scenario_id": cluster + 1,
            "source_index": source_index,
            "cluster_n": int(np.sum(labels == cluster)),
            "probability": float(np.mean(labels == cluster)),
        }
        for feature in CLIMATE_FEATURES:
            if feature in train.columns:
                row[feature] = train.iloc[position][feature]
        rows.append(row)
    scenarios = pd.DataFrame(rows)

    # Name after clustering using observed properties; no preassigned dry/normal/wet labels.
    rain_rank = scenarios["Rainfall_Seasonal_mm"].rank(method="first").astype(int)
    temp_rank = scenarios["Temp_Avg_C"].rank(method="first").astype(int)
    rain_labels = {1: "lower-rain", 2: "middle-rain", 3: "higher-rain"}
    temp_labels = {1: "cooler", 2: "moderate-temperature", 3: "hotter"}
    names = []
    for i in range(len(scenarios)):
        names.append(
            f"{rain_labels[rain_rank.iloc[i]]}/{temp_labels[temp_rank.iloc[i]]} representative"
        )
    scenarios.insert(1, "scenario_name", names)
    state = {
        "features": features,
        "medians": medians.to_dict(),
        "scaler": scaler,
        "pca": pca,
        "z": z,
        "labels": labels,
        "medoid_positions": medoid_positions,
        "loss": loss,
        "explained_variance": float(pca.explained_variance_ratio_.sum()),
    }
    return scenarios, state


def scenario_candidate_frame(
    representative: pd.Series,
    model: FittedRegressor,
    scenario_row: pd.Series,
    variety: str,
    water: np.ndarray,
    fertilizer: float,
) -> pd.DataFrame:
    frame = candidate_frame(
        representative,
        model,
        np.asarray(water, dtype=float),
        np.full(len(water), float(fertilizer)),
    )
    for feature in CLIMATE_FEATURES:
        if feature in frame.columns and feature in scenario_row.index:
            frame[feature] = scenario_row[feature]
    frame["Variety"] = variety
    return frame


def evaluate_variety_water(
    model: FittedRegressor,
    representative: pd.Series,
    scenarios: pd.DataFrame,
    varieties: list[str],
    water_bounds: tuple[float, float],
    fertilizer: float,
    n_water: int = 501,
) -> pd.DataFrame:
    water_grid = np.linspace(*water_bounds, n_water)
    batches = []
    for variety in varieties:
        for _, scenario in scenarios.iterrows():
            frame = scenario_candidate_frame(
                representative, model, scenario, variety, water_grid, fertilizer
            )
            frame["__decision_variety"] = variety
            frame["__scenario_id"] = int(scenario["scenario_id"])
            frame["__decision_water"] = water_grid
            batches.append(frame)
    all_candidates = pd.concat(batches, ignore_index=True)
    all_candidates["__prediction"] = model.predict(all_candidates)
    wide = all_candidates.pivot_table(
        index=["__decision_variety", "__decision_water"],
        columns="__scenario_id",
        values="__prediction",
        aggfunc="first",
    ).reset_index()
    probability = scenarios.set_index("scenario_id")["probability"].astype(float)
    output = pd.DataFrame(
        {
            "Variety": wide["__decision_variety"],
            WATER: wide["__decision_water"].astype(float),
        }
    )
    scenario_columns = []
    for scenario_id in sorted(int(x) for x in probability.index):
        column = f"scenario_{scenario_id}_yield"
        output[column] = wide[scenario_id].astype(float)
        scenario_columns.append(column)
    output["worst_yield"] = output[scenario_columns].min(axis=1)
    output["expected_yield"] = sum(
        float(probability.loc[scenario_id]) * output[f"scenario_{scenario_id}_yield"]
        for scenario_id in sorted(int(x) for x in probability.index)
    )
    return output


def select_decisions(evaluation: pd.DataFrame) -> tuple[pd.Series, pd.Series]:
    robust = evaluation.sort_values(
        ["worst_yield", "expected_yield"], ascending=[False, False]
    ).iloc[0]
    expected = evaluation.sort_values(
        ["expected_yield", "worst_yield"], ascending=[False, False]
    ).iloc[0]
    return robust, expected


def scenario_bootstrap_stability(
    model: FittedRegressor,
    representative: pd.Series,
    train: pd.DataFrame,
    scenarios: pd.DataFrame,
    state: dict,
    varieties: list[str],
    water_bounds: tuple[float, float],
    fertilizer: float,
    n_boot: int = 100,
) -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    z = state["z"]
    labels = state["labels"]
    rows = []
    for b in range(n_boot):
        boot_rows = []
        for cluster in range(3):
            members = np.flatnonzero(labels == cluster)
            sampled = rng.choice(members, size=len(members), replace=True)
            center = z[sampled].mean(axis=0)
            medoid_position = members[np.argmin(np.linalg.norm(z[members] - center, axis=1))]
            source = train.iloc[medoid_position]
            row = {
                "scenario_id": cluster + 1,
                "probability": len(members) / len(train),
            }
            for feature in CLIMATE_FEATURES:
                if feature in source.index:
                    row[feature] = source[feature]
            boot_rows.append(row)
        boot_scenarios = pd.DataFrame(boot_rows)
        evaluation = evaluate_variety_water(
            model,
            representative,
            boot_scenarios,
            varieties,
            water_bounds,
            fertilizer,
            n_water=151,
        )
        robust, expected = select_decisions(evaluation)
        rows.append(
            {
                "bootstrap": b,
                "robust_variety": robust["Variety"],
                "robust_water": robust[WATER],
                "robust_worst_yield": robust["worst_yield"],
                "expected_variety": expected["Variety"],
                "expected_water": expected[WATER],
                "expected_expected_yield": expected["expected_yield"],
            }
        )
    return pd.DataFrame(rows)


def make_q3_figures(
    figure_dir: Path,
    scenarios: pd.DataFrame,
    evaluation: pd.DataFrame,
    robust: pd.Series,
    expected: pd.Series,
    model_stability: pd.DataFrame | None = None,
) -> None:
    figure_dir.mkdir(parents=True, exist_ok=True)
    plt.style.use("seaborn-v0_8-whitegrid")
    vars_for_plot = [
        "Temp_Avg_C",
        "Rainfall_Seasonal_mm",
        "Humidity_%",
        "Solar_Radiation_MJ_m2_day",
        "Evapotranspiration_mm_day",
        "Heat_Stress_Days",
        "Frost_Days",
    ]
    matrix = scenarios[vars_for_plot].astype(float)
    norm = (matrix - matrix.mean()) / matrix.std(ddof=0).replace(0, 1)
    short_labels = [
        "Avg temp\n(°C)",
        "Seasonal rain\n(mm)",
        "Humidity\n(%)",
        "Solar radiation\n(MJ/(m²·day))",
        "ET\n(mm/day)",
        "Heat-stress\ndays",
        "Frost\ndays",
    ]
    fig, ax = plt.subplots(figsize=(10.4, 4.0), constrained_layout=True)
    image = ax.imshow(norm.to_numpy(), aspect="auto", cmap="RdBu_r", vmin=-2, vmax=2)
    fig.colorbar(image, ax=ax, label="Within-variable standardized value")
    ax.set_xticks(np.arange(len(vars_for_plot)), short_labels)
    ax.set_yticks(np.arange(len(scenarios)), scenarios["scenario_name"])
    for row, column in np.argwhere(matrix.isna().to_numpy()):
        ax.text(column, row, "NA", ha="center", va="center", fontsize=8, color="#333333")
    ax.set_title("Three real-medoid climate scenarios")
    for ext in ("pdf", "png"):
        fig.savefig(figure_dir / f"q3_climate_scenarios.{ext}", dpi=320 if ext == "png" else None)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8.0, 5.0), constrained_layout=True)
    palette = ["#4C78A8", "#F28E2B", "#59A14F"]
    for color, (variety, part) in zip(palette, evaluation.groupby("Variety")):
        ax.plot(part[WATER], part["worst_yield"], label=variety, color=color, linewidth=1.8)
    ax.scatter(robust[WATER], robust["worst_yield"], marker="*", s=170, color="#D55E00", edgecolor="black", zorder=5, label="max-min decision")
    ax.set_xlabel("Irrigation quantity (m³/acre; interpreted)")
    ax.set_ylabel("Worst-scenario predicted yield (quintal/acre)")
    ax.set_title("Robust variety–irrigation decision")
    ax.legend()
    for ext in ("pdf", "png"):
        fig.savefig(figure_dir / f"q3_robust_decision.{ext}", dpi=320 if ext == "png" else None)
    plt.close(fig)

    scenario_cols = [c for c in evaluation.columns if c.startswith("scenario_") and c.endswith("_yield")]
    labels = ["robust max-min", "expected-value"]
    rows = [robust, expected]
    x = np.arange(len(scenario_cols))
    width = 0.36
    fig, ax = plt.subplots(figsize=(7.6, 4.6), constrained_layout=True)
    for i, (label, row) in enumerate(zip(labels, rows)):
        ax.bar(x + (i - 0.5) * width, [row[c] for c in scenario_cols], width=width, label=label)
    ax.set_xticks(x, [f"Scenario {i+1}" for i in range(len(scenario_cols))])
    ax.set_ylabel("Predicted yield (quintal/acre)")
    ax.set_title("Scenario outcomes of two decision rules")
    ax.legend()
    for ext in ("pdf", "png"):
        fig.savefig(figure_dir / f"q3_decision_comparison.{ext}", dpi=320 if ext == "png" else None)
    plt.close(fig)

    if model_stability is not None and not model_stability.empty:
        stability = model_stability.copy()
        counts = stability["robust_variety"].value_counts(normalize=True).sort_values(ascending=False)
        ordered_varieties = counts.index.tolist()
        colors = {name: palette[i % len(palette)] for i, name in enumerate(ordered_varieties)}
        fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.5), constrained_layout=True)
        axes[0].bar(counts.index, counts.values, color=[colors[v] for v in counts.index], edgecolor="white")
        axes[0].set_ylim(0, 1)
        axes[0].set_ylabel("Selection rate")
        axes[0].set_title("Robust variety across response models")
        for x_pos, value in enumerate(counts.values):
            axes[0].text(x_pos, value + 0.025, f"{value:.0%}", ha="center", va="bottom")

        rng = np.random.default_rng(20260728)
        for x_pos, variety in enumerate(ordered_varieties):
            values = stability.loc[stability["robust_variety"] == variety, "robust_water"].to_numpy(dtype=float)
            jitter = rng.uniform(-0.09, 0.09, size=len(values))
            axes[1].scatter(
                np.full(len(values), x_pos) + jitter,
                values,
                s=42,
                color=colors[variety],
                edgecolor="white",
                linewidth=0.5,
                alpha=0.9,
            )
        axes[1].set_xticks(np.arange(len(ordered_varieties)), ordered_varieties)
        axes[1].set_ylabel("Robust irrigation quantity (m^3/acre)")
        axes[1].set_title("Recommended water varies by response model")
        fig.suptitle("Response-model uncertainty changes the Question 3 recommendation", fontsize=12)
        for ext in ("pdf", "png"):
            fig.savefig(figure_dir / f"q3_response_model_stability.{ext}", dpi=320 if ext == "png" else None)
        plt.close(fig)


def run_q3(
    model: FittedRegressor,
    train: pd.DataFrame,
    representative: pd.Series,
    water_bounds: tuple[float, float],
    q2_fertilizer: float,
    output_dir: str | Path,
    figure_dir: str | Path,
    bootstrap_models: list[FittedRegressor] | None = None,
) -> dict:
    output_dir = Path(output_dir)
    figure_dir = Path(figure_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)

    scenarios, state = build_scenarios(train)
    scenarios.to_csv(output_dir / "q3_climate_scenarios.csv", index=False, encoding="utf-8-sig")
    varieties = sorted(train["Variety"].dropna().astype(str).unique().tolist())
    evaluation = evaluate_variety_water(
        model,
        representative,
        scenarios,
        varieties,
        water_bounds,
        float(q2_fertilizer),
        n_water=501,
    )
    robust, expected = select_decisions(evaluation)
    evaluation.to_csv(output_dir / "q3_variety_water_grid.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(
        [
            {"decision_rule": "max-min robust", **robust.to_dict()},
            {"decision_rule": "probability-weighted expected value", **expected.to_dict()},
        ]
    ).to_csv(output_dir / "q3_decision_comparison.csv", index=False, encoding="utf-8-sig")

    stability = scenario_bootstrap_stability(
        model,
        representative,
        train,
        scenarios,
        state,
        varieties,
        water_bounds,
        float(q2_fertilizer),
        n_boot=100,
    )
    stability.to_csv(output_dir / "q3_scenario_bootstrap_stability.csv", index=False, encoding="utf-8-sig")
    robust_choice_rate = (
        stability.groupby("robust_variety").size() / len(stability)
    ).sort_values(ascending=False)
    model_stability_rows = []
    if bootstrap_models:
        for i, boot_model in enumerate(bootstrap_models):
            boot_evaluation = evaluate_variety_water(
                boot_model,
                representative,
                scenarios,
                varieties,
                water_bounds,
                float(q2_fertilizer),
                n_water=151,
            )
            boot_robust, boot_expected = select_decisions(boot_evaluation)
            model_stability_rows.append(
                {
                    "bootstrap_model": i + 1,
                    "robust_variety": boot_robust["Variety"],
                    "robust_water": boot_robust[WATER],
                    "robust_worst_yield": boot_robust["worst_yield"],
                    "expected_variety": boot_expected["Variety"],
                    "expected_water": boot_expected[WATER],
                }
            )
    model_stability = pd.DataFrame(model_stability_rows)
    model_stability.to_csv(
        output_dir / "q3_response_model_stability.csv", index=False, encoding="utf-8-sig"
    )
    scenario_cols = [c for c in evaluation.columns if c.startswith("scenario_") and c.endswith("_yield")]
    price_of_robustness = float(expected["expected_yield"] - robust["expected_yield"])
    worst_case_gain = float(robust["worst_yield"] - expected["worst_yield"])
    summary = {
        "random_seed": SEED,
        "scenario_method": "robust scaling + PCA(90% variance) + 3-cluster PAM K-medoids",
        "pca_explained_variance": state["explained_variance"],
        "pam_objective": state["loss"],
        "scenario_probabilities": scenarios.set_index("scenario_name")["probability"].to_dict(),
        "fixed_fertilizer_kg_acre": float(q2_fertilizer),
        "robust_decision": {k: (str(v) if k == "Variety" else float(v)) for k, v in robust.to_dict().items()},
        "expected_value_decision": {k: (str(v) if k == "Variety" else float(v)) for k, v in expected.to_dict().items()},
        "price_of_robustness_expected_yield": price_of_robustness,
        "robust_worst_case_gain": worst_case_gain,
        "bootstrap_repetitions": len(stability),
        "robust_variety_selection_rates": robust_choice_rate.to_dict(),
        "robust_water_bootstrap_interval": [
            float(stability["robust_water"].quantile(0.025)),
            float(stability["robust_water"].quantile(0.975)),
        ],
        "scenario_yield_columns": scenario_cols,
    }
    if not model_stability.empty:
        summary["response_model_variety_selection_rates"] = (
            model_stability["robust_variety"].value_counts(normalize=True).to_dict()
        )
        summary["response_model_water_interval"] = [
            float(model_stability["robust_water"].quantile(0.025)),
            float(model_stability["robust_water"].quantile(0.975)),
        ]
    (output_dir / "q3_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    make_q3_figures(figure_dir, scenarios, evaluation, robust, expected, model_stability)
    return {
        "scenarios": scenarios,
        "evaluation": evaluation,
        "robust": robust,
        "expected": expected,
        "stability": stability,
        "summary": summary,
    }
