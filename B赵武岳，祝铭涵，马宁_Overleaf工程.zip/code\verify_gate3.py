"""Independent Gate 3 verification for the 2026 sugarcane B problem.

The verifier reads saved artifacts rather than trusting in-memory objects.  It
does not mutate the source data and writes a machine-readable check ledger.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import py_compile
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image


EXPECTED_RAW_SHA256 = (
    "DD8D3B5A4BBD2D9DB659C2C2FCBF7442"
    "B1416E09921B674CB7046E8A659B615A"
)
WATER = "Water_Quantity_liters_per_acre"
FERTILIZER = "Fertilizer_Quantity"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_root", type=Path)
    parser.add_argument("raw_csv", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    raw_csv = args.raw_csv.resolve()
    results = root / "results"
    figures = root / "manuscript" / "figures"
    checks: list[dict[str, str]] = []

    def record(check: str, passed: bool, evidence: object, *, warning: bool = False) -> None:
        checks.append(
            {
                "check": check,
                "status": "WARN" if warning else ("PASS" if passed else "FAIL"),
                "evidence": str(evidence),
            }
        )

    # Source immutability and reproducibility anchors.
    raw_hash = sha256(raw_csv)
    record("raw CSV SHA-256 unchanged", raw_hash == EXPECTED_RAW_SHA256, raw_hash)
    manifest = json.loads((results / "run_manifest.json").read_text(encoding="utf-8"))
    manifest_hashes = {
        str(manifest.get("raw_sha256_before", "")).upper(),
        str(manifest.get("raw_sha256_after", "")).upper(),
    }
    record(
        "run manifest records identical before/after source hashes",
        manifest_hashes == {EXPECTED_RAW_SHA256} and bool(manifest.get("raw_immutable_check_passed")),
        sorted(manifest_hashes),
    )

    # Question 1: locked temporal holdouts and finite saved metrics.
    q1 = json.loads((results / "q1" / "q1_summary.json").read_text(encoding="utf-8"))
    record("Q1 selected model obeys the predeclared parsimony rule", q1["selected_model"] == "Elastic Net", q1["selected_model"])
    holdout = pd.read_csv(results / "q1" / "holdout_metrics.csv")
    selected = holdout[holdout["model"] == q1["selected_model"]]
    required_splits = {"2023_validation", "2024_test_locked"}
    record("Q1 contains both temporal holdouts", set(selected["split"]) == required_splits, sorted(selected["split"].tolist()))
    q1_numeric = selected[["RMSE", "MAE", "R2", "NRMSE_mean", "MAPE_pct", "bias"]].to_numpy(dtype=float)
    record("Q1 saved holdout metrics are finite", bool(np.isfinite(q1_numeric).all()), q1_numeric.shape)
    locked_r2 = float(selected.loc[selected["split"] == "2024_test_locked", "R2"].iloc[0])
    record("Q1 locked 2024 R2 clears the declared quality gate", locked_r2 >= 0.30, f"R2={locked_r2:.6f}")

    # Question 2: recomputation, feasibility and boundary/model-instability warnings.
    q2 = json.loads((results / "q2" / "q2_summary.json").read_text(encoding="utf-8"))
    decision = q2["main_decision"]
    audit = q2["independent_recalculation"]
    record("Q2 decision is budget-feasible", bool(audit["feasible"]), f"cost={audit['cost_rmb_ha']:.6f}")
    record(
        "Q2 independent objective and cost recomputation agree",
        audit["prediction_abs_difference"] <= 1e-9 and audit["cost_abs_difference"] <= 1e-9,
        f"prediction diff={audit['prediction_abs_difference']:.3e}; cost diff={audit['cost_abs_difference']:.3e}",
    )
    water_bounds = np.asarray(q2["water_support_q05_q95"], dtype=float)
    fert_bounds = np.asarray(q2["fertilizer_support_q05_q95"], dtype=float)
    record(
        "Q2 decision stays inside observed support",
        water_bounds[0] - 1e-9 <= decision["water_m3_acre"] <= water_bounds[1] + 1e-9
        and fert_bounds[0] - 1e-9 <= decision["fertilizer_kg_acre"] <= fert_bounds[1] + 1e-9,
        f"water={decision['water_m3_acre']:.3f}; fertilizer={decision['fertilizer_kg_acre']:.3f}",
    )
    boundary = q2["main_solution_hits_support_boundary"]
    record("Q2 optimum does not rely on a support boundary", not any(boundary.values()), boundary, warning=any(boundary.values()))
    effects = pd.read_csv(results / "q2" / "q2_decision_effect_stability.csv")
    record("Q2 response-model stability uses 20 resamples", len(effects) == 20, f"n={len(effects)}")
    direction = q2["bootstrap_effect_direction"]
    stable_direction = direction["water_positive_rate"] >= 0.80 and direction["fertilizer_positive_rate"] >= 0.80
    record("Q2 water/fertilizer effect directions are stable", stable_direction, direction, warning=not stable_direction)

    # Question 3: scenario probabilities and independent decision aggregation.
    scenarios = pd.read_csv(results / "q3" / "q3_climate_scenarios.csv")
    q3_decisions = pd.read_csv(results / "q3" / "q3_decision_comparison.csv")
    record("Q3 has exactly three real-medoid scenarios", len(scenarios) == 3 and scenarios["source_index"].nunique() == 3, f"n={len(scenarios)}")
    probabilities = scenarios["probability"].to_numpy(dtype=float)
    record("Q3 scenario probabilities sum to one", abs(probabilities.sum() - 1.0) <= 1e-12, f"sum={probabilities.sum():.12f}")
    scenario_columns = [column for column in q3_decisions.columns if column.startswith("scenario_") and column.endswith("_yield")]
    aggregation_ok = True
    aggregation_diffs: list[float] = []
    for _, row in q3_decisions.iterrows():
        values = row[scenario_columns].to_numpy(dtype=float)
        diffs = [abs(float(row["worst_yield"]) - float(values.min())), abs(float(row["expected_yield"]) - float(values @ probabilities))]
        aggregation_diffs.extend(diffs)
        aggregation_ok &= max(diffs) <= 1e-9
    record("Q3 worst-case and expected yields recompute exactly", aggregation_ok, f"max diff={max(aggregation_diffs):.3e}")
    q3_stability = pd.read_csv(results / "q3" / "q3_response_model_stability.csv")
    q3_stable = q3_stability["robust_variety"].value_counts(normalize=True).max() >= 0.80
    record("Q3 robust variety is stable across response models", q3_stable, q3_stability["robust_variety"].value_counts().to_dict(), warning=not q3_stable)

    # Question 4: formula audit and strict non-dominance of the saved frontier.
    q4 = json.loads((results / "q4" / "q4_summary.json").read_text(encoding="utf-8"))
    compromise = q4["compromise"]
    w_norm = (compromise[WATER] - water_bounds[0]) / (water_bounds[1] - water_bounds[0])
    f_norm = (compromise[FERTILIZER] - fert_bounds[0]) / (fert_bounds[1] - fert_bounds[0])
    environment_recomputed = 0.5 * w_norm**2 + 0.5 * f_norm**2
    record(
        "Q4 environmental pressure formula recomputes",
        abs(environment_recomputed - compromise["environmental_pressure"]) <= 1e-12,
        f"diff={abs(environment_recomputed - compromise['environmental_pressure']):.3e}",
    )
    frontier = pd.read_csv(results / "q4" / "q4_pareto_frontier.csv")
    y = frontier["predicted_yield"].to_numpy(dtype=float)
    e = frontier["environmental_pressure"].to_numpy(dtype=float)
    dominated = np.zeros(len(frontier), dtype=bool)
    for i in range(len(frontier)):
        dominated[i] = bool(np.any((y >= y[i]) & (e <= e[i]) & ((y > y[i]) | (e < e[i]))))
    record("Q4 saved frontier contains no strictly dominated point", not dominated.any(), f"dominated={int(dominated.sum())}")
    record("Q4 independent compromise audit reports zero dominators", q4["independent_recalculation"]["number_of_strict_grid_dominators"] == 0, q4["independent_recalculation"])

    # Question 5: complete rankings and uncertainty calibration.
    q5 = pd.read_csv(results / "q5" / "q5_final_ranking.csv")
    ranks = sorted(q5["rank"].astype(int).tolist())
    record("Q5 ranks all six variety-season combinations once", len(q5) == 6 and ranks == list(range(1, 7)), ranks)
    q5_prob_ok = bool(q5[["rank1_probability", "top3_probability"]].apply(lambda s: s.between(0, 1).all()).all())
    record("Q5 bootstrap probabilities are valid", q5_prob_ok, "all probabilities in [0,1]")
    bootstrap_ranks = pd.read_csv(results / "q5" / "q5_bootstrap_ranks.csv")
    complete_bootstrap = len(bootstrap_ranks) == 500 * 6 and bootstrap_ranks.groupby("bootstrap")["rank"].nunique().eq(6).all()
    record("Q5 contains 500 complete ranking resamples", bool(complete_bootstrap), f"rows={len(bootstrap_ranks)}")
    stable_top3 = bool((q5.nlargest(3, "topsis_score")["top3_probability"] >= 0.70).all())
    record("Q5 reported Top-3 ordering is stable at 70%", stable_top3, q5.nlargest(3, "topsis_score")[["combo", "top3_probability"]].to_dict("records"), warning=not stable_top3)

    # Code syntax and figure artifact QA.
    compile_failures: list[str] = []
    for source in sorted((root / "code").glob("*.py")):
        try:
            py_compile.compile(str(source), doraise=True)
        except py_compile.PyCompileError as error:
            compile_failures.append(f"{source.name}: {error.msg}")
    record("all Python sources compile", not compile_failures, compile_failures or "no syntax errors")

    pngs = sorted(figures.glob("*.png"))
    pdfs = {path.stem: path for path in figures.glob("*.pdf")}
    missing_pairs: list[str] = []
    low_resolution: list[str] = []
    bad_pdf: list[str] = []
    for png in pngs:
        if png.stem not in pdfs:
            missing_pairs.append(png.name)
        with Image.open(png) as image:
            if image.width < 2000 or image.height < 1100:
                low_resolution.append(f"{png.name}:{image.width}x{image.height}")
    for stem, pdf in pdfs.items():
        if not (figures / f"{stem}.png").exists():
            missing_pairs.append(pdf.name)
        if pdf.read_bytes()[:4] != b"%PDF":
            bad_pdf.append(pdf.name)
    record("every figure has PNG and vector-PDF versions", not missing_pairs and len(pngs) >= 16, f"pairs={len(pngs)}; missing={missing_pairs}")
    record("all PNG figures meet the minimum pixel dimensions", not low_resolution, low_resolution or "all >=2000x1100")
    record("all PDF figures have a valid PDF header", not bad_pdf, bad_pdf or "all start with %PDF")

    ledger = pd.DataFrame(checks)
    ledger.to_csv(results / "final_verification_checks.csv", index=False, encoding="utf-8-sig")
    fail_count = int((ledger["status"] == "FAIL").sum())
    warning_count = int((ledger["status"] == "WARN").sum())
    summary = {
        "overall_computational_verification": "PASS" if fail_count == 0 else "FAIL",
        "checks": len(ledger),
        "pass": int((ledger["status"] == "PASS").sum()),
        "warnings": warning_count,
        "failures": fail_count,
        "warning_interpretation": "Warnings preserve substantive uncertainty; they do not invalidate numerical reproduction.",
        "raw_sha256": raw_hash,
    }
    (results / "final_verification_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if fail_count:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
